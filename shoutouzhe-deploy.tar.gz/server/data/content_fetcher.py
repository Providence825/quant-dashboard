import requests
import re
import json
import time
from datetime import datetime
from ..db import get_db

BILI_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Referer': 'https://www.bilibili.com',
}

def _fetch_bilibili_search(keyword, count=5):
    """Search B站 for videos matching keyword. Returns list of {title, url, date, description}."""
    results = []
    try:
        resp = requests.get(
            'https://api.bilibili.com/x/web-interface/search/type',
            params={'search_type': 'video', 'keyword': keyword, 'order': 'pubdate', 'page': 1},
            headers=BILI_HEADERS, timeout=8
        )
        if resp.status_code == 200:
            data = resp.json()
            if data.get('code') == 0 and 'data' in data and 'result' in data['data']:
                for v in data['data']['result'][:count]:
                    pubdate_ts = v.get('pubdate', 0)
                    pubdate = datetime.fromtimestamp(pubdate_ts).strftime('%Y-%m-%d') if pubdate_ts else ''
                    results.append({
                        'title': re.sub(r'<[^>]+>', '', v.get('title', '')),
                        'url': f'https://www.bilibili.com/video/{v.get("bvid", "")}',
                        'date': pubdate,
                        'description': (v.get('description', '') or '')[:300],
                        'play': v.get('play', 0),
                        'source': 'B站'
                    })
    except Exception as e:
        print(f'[B站搜索失败] {e}')
    return results


def _search_web_360(keyword, count=5):
    """Use 360 search as a fallback to find content mentions."""
    results = []
    try:
        resp = requests.get(
            'https://www.so.com/s',
            params={'q': keyword, 'pn': 1},
            headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'},
            timeout=8
        )
        if resp.status_code == 200:
            # Extract links and titles from HTML
            from html.parser import HTMLParser

            class LinkParser(HTMLParser):
                def __init__(self):
                    super().__init__()
                    self.items = []
                    self.current = {}
                    self.in_title = False
                    self.in_abstract = False

                def handle_starttag(self, tag, attrs):
                    attrs = dict(attrs)
                    if tag == 'a' and 'res-title' in attrs.get('class', ''):
                        self.current = {'url': attrs.get('href', '')}
                    if tag == 'h3' or ('res-title' in attrs.get('class', '')):
                        self.in_title = True
                    if 'res-desc' in attrs.get('class', ''):
                        self.in_abstract = True

                def handle_data(self, data):
                    if self.in_title:
                        self.current['title'] = (self.current.get('title', '') + ' ' + data).strip()
                    if self.in_abstract:
                        self.current['abstract'] = (self.current.get('abstract', '') + ' ' + data).strip()

                def handle_endtag(self, tag):
                    self.in_title = False
                    self.in_abstract = False
                    if tag == 'a' and self.current.get('title'):
                        self.items.append(self.current.copy())
                        self.current = {}

            parser = LinkParser()
            parser.feed(resp.text)

            for item in parser.items[:count]:
                results.append({
                    'title': item.get('title', ''),
                    'url': item.get('url', ''),
                    'date': '',
                    'description': item.get('abstract', '')[:300],
                    'source': '网页'
                })
    except Exception as e:
        print(f'[360搜索失败] {e}')
    return results


def fetch_fuzong_content():
    """Fetch latest content from 福总 (机构一手调研)."""
    entries = []

    # Strategy 1: B站 search (福总 may have B站 mirror)
    bili = _fetch_bilibili_search('机构一手调研 福总', 5)
    entries.extend(bili)

    # Strategy 2: Web search for mentions
    try:
        resp = requests.get(
            'https://www.so.com/s',
            params={'q': '机构一手调研 福总 股票 半导体', 'pn': 1},
            headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'},
            timeout=8
        )
        if resp.status_code == 200:
            # Extract URLs from search results for reference
            urls = re.findall(r'https?://[^\s"\'<>]+', resp.text)
            for url in urls[:5]:
                if any(d in url for d in ['douyin.com', 'xueqiu.com', 'weixin.qq.com', 'zhihu.com']):
                    entries.append({
                        'title': url.split('/')[-1][:50] or '福总相关',
                        'url': url,
                        'date': '',
                        'description': f'搜索发现福总相关内容',
                        'source': '网络'
                    })
    except:
        pass

    return entries[:8]


def fetch_lqvx_content():
    """Fetch latest content from 来去由心 (B站UP主)."""
    entries = []

    # B站 direct search
    bili = _fetch_bilibili_search('来去由心', 10)
    entries.extend(bili)

    if not entries:
        # Fallback: broader search
        bili2 = _fetch_bilibili_search('来去由心 趋势票 买点', 5)
        entries.extend(bili2)

    return entries[:10]


def run_content_aggregator():
    """Main entry: fetch content from both sources and save to DB."""
    today = datetime.now().strftime('%Y-%m-%d')
    db = get_db()
    saved = {'fuzong': 0, 'laiqu': 0}
    try:
        return _run_content_aggregator_body(db, today, saved)
    finally:
        db.close()


def _run_content_aggregator_body(db, today, saved):
    # --- 福总 ---
    fuzong_entries = fetch_fuzong_content()
    if fuzong_entries:
        content_lines = []
        for i, e in enumerate(fuzong_entries):
            date_str = f' ({e["date"]})' if e['date'] else ''
            content_lines.append(
                f"{i+1}. 【{e['source']}】{e['title']}{date_str}\n"
                f"   {e['description'][:200]}\n"
                f"   {e['url']}"
            )
        full_content = '福总（机构一手调研）最新动态：\n\n' + '\n\n'.join(content_lines)

        db.execute(
            "INSERT INTO market_notes (source, content, note_date) VALUES (?,?,?)",
            ('机构一手调研（福总）', full_content, today)
        )
        db.commit()
        saved['fuzong'] = len(fuzong_entries)

    # --- 来去由心 ---
    laiqu_entries = fetch_lqvx_content()
    if laiqu_entries:
        content_lines = []
        for i, e in enumerate(laiqu_entries):
            plays = f' · {e["play"]}播放' if e.get('play') else ''
            date_str = f' ({e["date"]})' if e['date'] else ''
            content_lines.append(
                f"{i+1}. {e['title']}{date_str}{plays}\n"
                f"   {e['description'][:200]}\n"
                f"   {e['url']}"
            )
        full_content = '来去由心（B站）最新视频：\n\n' + '\n\n'.join(content_lines)

        db.execute(
            "INSERT INTO market_notes (source, content, note_date) VALUES (?,?,?)",
            ('B站·来去由心', full_content, today)
        )
        db.commit()
        saved['laiqu'] = len(laiqu_entries)

    return saved


def get_latest_notes(source=None):
    """Get latest aggregated notes from DB."""
    today = datetime.now().strftime('%Y-%m-%d')
    db = get_db()
    try:
        if source:
            rows = db.execute(
                "SELECT * FROM market_notes WHERE note_date=? AND source=? ORDER BY created_at DESC",
                (today, source)
            ).fetchall()
        else:
            rows = db.execute(
                "SELECT * FROM market_notes WHERE note_date=? ORDER BY created_at DESC",
                (today,)
            ).fetchall()
    finally:
        db.close()
    return [dict(r) for r in rows]
