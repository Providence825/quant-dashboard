"""Import all A-share stocks + historical K-line from Sina API into local DB."""
import time
import threading
from datetime import datetime

import requests

from .fetcher import _fetch_sina_json, _kline_prefix

SINA_LIST_URL = 'http://vip.stock.finance.sina.com.cn/quotes_service/api/json_v2.php/Market_Center.getHQNodeData'
SINA_KLINE_URL = 'https://quotes.sina.cn/cn/api/json_v2.php/CN_MarketData.getKLineData'

_import_lock = threading.Lock()


# ── Sector keyword matching ──────────────────────────────────────────

_KEYWORD_SECTORS = [
    ('半导体', ['半导体', '芯片']),
    ('通信', ['通信', '5G']),
    ('人工智能', ['人工智能', 'AI', '智能']),
    ('消费电子', ['电子', '精密']),
    ('软件', ['软件', '信创', '信息']),
    ('大数据', ['数据']),
    ('云计算', ['云计算', '云服务']),
    ('机器人', ['机器人']),
    ('军工', ['军工']),
    ('新能源', ['新能源', '锂电', '电池', '储能', '光伏', '风电']),
    ('汽车', ['汽车', '整车', '新能源车']),
    ('工业母机', ['机床', '数控']),
    ('航天航空', ['航空', '航天', '卫星']),
    ('机械设备', ['机械', '设备']),
    ('白酒', ['白酒', '酒业']),
    ('食品饮料', ['食品', '饮料', '乳业', '水产', '米面']),
    ('家电', ['家电', '电器']),
    ('农林牧渔', ['农业', '养殖', '种业', '饲料', '兽药', '牧原']),
    ('纺织服装', ['纺织', '服装', '家纺', '服饰']),
    ('旅游', ['旅游', '酒店', '免税']),
    ('传媒', ['传媒', '影视', '游戏', '广告', '出版']),
    ('医药', ['医药', '制药', '生物', '药', '医疗', '器械', '中药', '疫苗']),
    ('银行', ['银行']),
    ('券商', ['证券', '券商']),
    ('保险', ['保险']),
    ('房地产', ['地产', '房地产', '园区']),
    ('基建', ['基建', '建筑', '路桥', '设计', '水泥']),
    ('煤炭', ['煤炭', '煤业', '采煤']),
    ('钢铁', ['钢铁', '钢', '铁']),
    ('有色', ['有色', '金属', '矿', '黄金', '铜', '铝', '稀土']),
    ('化工', ['化工', '化学', '材料', '纤维', '塑料', '橡胶']),
    ('石油石化', ['石油', '石化', '油气', '天然气']),
    ('电力', ['电力', '发电', '配电', '电网']),
    ('交通运输', ['交通', '运输', '港口', '机场', '高速', '铁路']),
    ('环保', ['环保', '水务', '废水', '固废']),
    ('电力设备', ['电网', '变压器', '开关', '线缆']),
    ('贸易', ['贸易', '商贸', '供应链']),
]


def _determine_sector(name):
    for sector, keywords in _KEYWORD_SECTORS:
        for kw in keywords:
            if kw in name:
                return sector
    return ''


def _determine_market_board(code):
    """Return (market, board) from 6-digit stock code."""
    if code.startswith('6'):
        return ('sh', 'kcbj' if code.startswith('688') else 'main')
    elif code.startswith('0'):
        return ('sz', 'main')
    elif code.startswith('3'):
        return ('sz', 'cy')
    elif code.startswith('2'):
        return ('sz', 'main')  # SME / 中小板
    elif code.startswith('92'):
        return ('bj', 'bj')
    elif code.startswith(('8', '9')):
        return ('bj', 'bj')
    return ('sz', 'main')


# ── Stock list import ────────────────────────────────────────────────

def _spawn(worker, *args):
    """Launch a blocking import worker in a daemon thread.

    Returns immediately so the HTTP request does not exceed the client
    timeout. Progress/result are written to sync_log and polled by the
    frontend via get_import_status().
    """
    if _import_lock.locked():
        return {'success': False, 'error': '另一个任务正在运行'}
    t = threading.Thread(target=worker, args=args, daemon=True)
    t.start()
    return {'success': True, 'started': True}


def import_all_stocks():
    return _spawn(_do_import_all_stocks)


def import_kline_history(stock_codes=None, days_back=250):
    return _spawn(_do_import_kline_history, stock_codes, days_back)


def sync_daily_prices():
    return _spawn(_do_sync_daily_prices)


def _do_import_all_stocks():
    """Paginate Sina hs_a node and upsert all A-share stocks into DB."""
    from ..db import get_db

    if not _import_lock.acquire(blocking=False):
        return {'success': False, 'error': '另一个导入任务正在运行'}

    log_id = None
    db = get_db()
    try:
        cur = db.execute(
            "INSERT INTO sync_log (task, status, started_at) VALUES ('import_stocks','running',?)",
            (datetime.now().strftime('%Y-%m-%d %H:%M:%S'),))
        db.commit()
        log_id = cur.lastrowid

        total_pages = 0
        total_inserted = 0

        for page in range(1, 100):
            data = _fetch_sina_json(SINA_LIST_URL, params={
                'page': page, 'num': 100, 'sort': 'symbol', 'asc': 1, 'node': 'hs_a'
            }, timeout=15)
            if not data or not isinstance(data, list) or len(data) == 0:
                break

            total_pages += 1
            batch = []
            for s in data:
                code = s.get('code', '')
                name = s.get('name', '')
                if not code or not name:
                    continue
                market, board = _determine_market_board(code)
                sector = _determine_sector(name)
                batch.append((code, name, market, board, sector))

            if batch:
                db.executemany(
                    "INSERT OR REPLACE INTO stocks (code, name, market, board, sector) VALUES (?,?,?,?,?)",
                    batch)
                db.commit()
                total_inserted += len(batch)

            if page % 10 == 0:
                db.execute("UPDATE sync_log SET processed_items=? WHERE id=?",
                           (total_inserted, log_id))
                db.commit()

            time.sleep(0.25)  # Rate limit

        db.execute(
            "UPDATE sync_log SET status='completed', completed_at=?, total_items=?, processed_items=? WHERE id=?",
            (datetime.now().strftime('%Y-%m-%d %H:%M:%S'), total_pages, total_inserted, log_id))
        db.commit()
        return {'success': True, 'pages': total_pages, 'stocks': total_inserted}
    except Exception as e:
        try:
            db.execute("UPDATE sync_log SET status='failed', error_message=?, completed_at=? WHERE id=?",
                       (str(e), datetime.now().strftime('%Y-%m-%d %H:%M:%S'), log_id) if log_id else (str(e), datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 0))
            db.commit()
        except Exception:
            pass
        return {'success': False, 'error': str(e)}
    finally:
        db.close()
        _import_lock.release()


# ── K-line import ────────────────────────────────────────────────────

def _do_import_kline_history(stock_codes=None, days_back=250):
    """Import historical daily K-line for stocks.

    Args:
        stock_codes: list of codes, or None for ALL stocks in DB
        days_back: how many trading days to fetch per stock
    """
    from ..db import get_db

    if not _import_lock.acquire(blocking=False):
        return {'success': False, 'error': '另一个导入任务正在运行'}

    db = get_db()
    log_id = None
    try:
        if stock_codes is None:
            rows = db.execute("SELECT code FROM stocks ORDER BY code").fetchall()
            stock_codes = [r['code'] for r in rows]

        if not stock_codes:
            return {'success': False, 'error': '没有找到股票数据，请先导入股票列表'}

        total = len(stock_codes)

        cur = db.execute(
            "INSERT INTO sync_log (task, status, started_at, total_items) VALUES ('import_kline','running',?,?)",
            (datetime.now().strftime('%Y-%m-%d %H:%M:%S'), total))
        db.commit()
        log_id = cur.lastrowid

        klines_inserted = 0
        processed = 0

        for i, code in enumerate(stock_codes):
            try:
                prefix = _kline_prefix(code)
                data = _fetch_sina_json(SINA_KLINE_URL, params={
                    'symbol': f'{prefix}{code}', 'scale': 240, 'datalen': days_back
                }, timeout=10)
                if data and isinstance(data, list):
                    batch = []
                    for k in data:
                        date = k.get('day', '')[:10]
                        try:
                            batch.append((
                                code, date,
                                float(k.get('open', 0)),
                                float(k.get('high', 0)),
                                float(k.get('low', 0)),
                                float(k.get('close', 0)),
                                float(k.get('volume', 0)),
                            ))
                        except (ValueError, TypeError):
                            continue
                    if batch:
                        db.executemany(
                            "INSERT OR REPLACE INTO stock_kline_daily "
                            "(stock_code, date, open, high, low, close, volume) "
                            "VALUES (?,?,?,?,?,?,?)", batch)
            except Exception:
                pass

            processed += 1
            time.sleep(0.12)

            # Commit every 100 stocks
            if processed % 100 == 0:
                db.commit()
                db.execute("UPDATE sync_log SET processed_items=? WHERE id=?",
                           (processed, log_id))
                db.commit()
                time.sleep(2)

        db.commit()
        klines_inserted = db.execute(
            "SELECT COUNT(*) as cnt FROM stock_kline_daily").fetchone()['cnt']

        db.execute(
            "UPDATE sync_log SET status='completed', completed_at=?, processed_items=? WHERE id=?",
            (datetime.now().strftime('%Y-%m-%d %H:%M:%S'), processed, log_id))
        db.commit()
        return {'success': True, 'stocks_processed': processed,
                'total_klines': klines_inserted}
    except Exception as e:
        try:
            db.execute(
                "UPDATE sync_log SET status='failed', error_message=?, completed_at=? WHERE id=?",
                (str(e), datetime.now().strftime('%Y-%m-%d %H:%M:%S'), log_id) if log_id else (str(e), datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 0))
            db.commit()
        except:
            pass
        return {'success': False, 'error': str(e)}
    finally:
        db.close()
        _import_lock.release()


# ── Daily sync ───────────────────────────────────────────────────────

def _do_sync_daily_prices():
    """Incremental sync: fetch recent 5 days for stocks not synced today."""
    from ..db import get_db

    if not _import_lock.acquire(blocking=False):
        return {'success': False, 'error': '另一个同步任务正在运行'}

    db = get_db()
    log_id = None
    try:
        today = datetime.now().strftime('%Y-%m-%d')
        rows = db.execute(
            "SELECT code FROM stocks WHERE last_sync IS NULL OR last_sync < ?",
            (today,)).fetchall()
        stock_codes = [r['code'] for r in rows]

        if not stock_codes:
            return {'success': True, 'message': '所有股票今日已同步', 'synced': 0}

        total = len(stock_codes)
        cur = db.execute(
            "INSERT INTO sync_log (task, status, started_at, total_items) VALUES ('sync_daily','running',?,?)",
            (datetime.now().strftime('%Y-%m-%d %H:%M:%S'), total))
        db.commit()
        log_id = cur.lastrowid

        processed = 0
        for i, code in enumerate(stock_codes):
            try:
                prefix = _kline_prefix(code)
                data = _fetch_sina_json(SINA_KLINE_URL, params={
                    'symbol': f'{prefix}{code}', 'scale': 240, 'datalen': 10
                }, timeout=8)
                batch = []
                if data and isinstance(data, list):
                    for k in data:
                        date = k.get('day', '')[:10]
                        try:
                            batch.append((
                                code, date,
                                float(k.get('open', 0)),
                                float(k.get('high', 0)),
                                float(k.get('low', 0)),
                                float(k.get('close', 0)),
                                float(k.get('volume', 0)),
                            ))
                        except (ValueError, TypeError):
                            continue
                    if batch:
                        db.executemany(
                            "INSERT OR REPLACE INTO stock_kline_daily "
                            "(stock_code, date, open, high, low, close, volume) "
                            "VALUES (?,?,?,?,?,?,?)", batch)
                # 只有真取到数据才标记已同步; 空返回/请求失败不更新 last_sync,
                # 下次同步会重试 (否则漏抓的股票永远停在旧价, 如北交所 07-17 缺口)。
                if batch:
                    db.execute("UPDATE stocks SET last_sync=? WHERE code=?", (today, code))
            except Exception:
                pass

            processed += 1
            time.sleep(0.08)

            if processed % 200 == 0:
                db.commit()
                db.execute("UPDATE sync_log SET processed_items=? WHERE id=?",
                           (processed, log_id))
                db.commit()
                time.sleep(1.5)

        db.commit()
        db.execute(
            "UPDATE sync_log SET status='completed', completed_at=?, processed_items=? WHERE id=?",
            (datetime.now().strftime('%Y-%m-%d %H:%M:%S'), processed, log_id))
        db.commit()
        return {'success': True, 'synced': processed}
    except Exception as e:
        try:
            db.execute(
                "UPDATE sync_log SET status='failed', error_message=?, completed_at=? WHERE id=?",
                (str(e), datetime.now().strftime('%Y-%m-%d %H:%M:%S'), log_id) if log_id else (str(e), datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 0))
            db.commit()
        except:
            pass
        return {'success': False, 'error': str(e)}
    finally:
        db.close()
        _import_lock.release()


# ── Status ────────────────────────────────────────────────────────────

def get_import_status():
    """Return current import job status."""
    from ..db import get_db
    db = get_db()
    try:
        row = db.execute(
            "SELECT * FROM sync_log ORDER BY id DESC LIMIT 1").fetchone()
    finally:
        db.close()
    if not row:
        return {'task': None, 'status': 'idle'}
    total = row['total_items']
    done = row['processed_items']
    return {
        'task': row['task'],
        'status': row['status'],
        'started_at': row['started_at'],
        'completed_at': row['completed_at'],
        'total_items': total,
        'processed_items': done,
        'progress_pct': round(done / total * 100, 1) if total else 0,
        'error': row['error_message'],
    }
