from datetime import datetime, timedelta
import threading

class Cache:
    def __init__(self, ttl_seconds=3):
        self._data = {}
        self._times = {}
        self._ttl = ttl_seconds
        self._lock = threading.Lock()

    def get(self, key):
        with self._lock:
            if key in self._data:
                if (datetime.now() - self._times[key]).total_seconds() < self._ttl:
                    return self._data[key]
        return None

    def set(self, key, value):
        with self._lock:
            self._data[key] = value
            self._times[key] = datetime.now()

    def clear(self):
        with self._lock:
            self._data.clear()
            self._times.clear()

cache = Cache(ttl_seconds=3)
