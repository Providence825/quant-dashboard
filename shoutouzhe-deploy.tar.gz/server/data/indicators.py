def calc_sma(data, period):
    result = []
    for i in range(len(data)):
        if i < period - 1:
            result.append(None)
        else:
            result.append(sum(data[i - period + 1:i + 1]) / period)
    return result


def calc_ema(data, period):
    if not data:
        return []
    k = 2 / (period + 1)
    ema = [data[0]]
    for i in range(1, len(data)):
        ema.append(data[i] * k + ema[-1] * (1 - k))
    return ema


def calc_macd(closes, fast=12, slow=26, signal=9):
    if len(closes) < slow:
        return [], [], []
    ema12 = calc_ema(closes, fast)
    ema26 = calc_ema(closes, slow)
    dif = [ema12[i] - ema26[i] for i in range(len(closes))]
    dea = calc_ema(dif, signal)
    hist = [dif[i] - dea[i] for i in range(len(dif))]
    return dif, dea, hist


def calc_kdj(highs, lows, closes, n=9, m1=3, m2=3):
    if len(closes) < n:
        return [], [], []
    k_vals = []
    d_vals = []
    j_vals = []
    for i in range(len(closes)):
        if i < n - 1:
            k_vals.append(None)
            d_vals.append(None)
            j_vals.append(None)
        else:
            high_n = max(highs[i - n + 1:i + 1])
            low_n = min(lows[i - n + 1:i + 1])
            rsv = (closes[i] - low_n) / (high_n - low_n) * 100 if high_n != low_n else 50
            if not k_vals or k_vals[-1] is None:
                prev_k = 50
                prev_d = 50
            else:
                prev_k = k_vals[-1]
                prev_d = d_vals[-1]
            k = prev_k * (1 - 1 / m1) + rsv * (1 / m1)
            d = prev_d * (1 - 1 / m2) + k * (1 / m2)
            j = 3 * k - 2 * d
            k_vals.append(k)
            d_vals.append(d)
            j_vals.append(j)
    return k_vals, d_vals, j_vals


def calc_atr(highs, lows, closes, period=14):
    """Average True Range (Wilder). Returns list aligned to input, None-padded."""
    n = len(closes)
    if n < 2 or not (len(highs) == len(lows) == n):
        return [None] * n
    trs = [None]
    for i in range(1, n):
        tr = max(highs[i] - lows[i],
                 abs(highs[i] - closes[i - 1]),
                 abs(lows[i] - closes[i - 1]))
        trs.append(tr)
    result = [None] * n
    if n <= period:
        return result
    first = sum(trs[1:period + 1]) / period
    result[period] = first
    prev = first
    for i in range(period + 1, n):
        prev = (prev * (period - 1) + trs[i]) / period
        result[i] = prev
    return result


def calc_rsi(closes, period=14):
    if len(closes) < period + 1:
        return [None] * len(closes)
    result = [None] * period
    gains = []
    losses = []
    for i in range(1, len(closes)):
        diff = closes[i] - closes[i - 1]
        gains.append(max(0, diff))
        losses.append(abs(min(0, diff)))
    for i in range(period, len(closes)):
        avg_gain = sum(gains[i - period:i]) / period
        avg_loss = sum(losses[i - period:i]) / period
        if avg_loss == 0:
            result.append(100)
        else:
            result.append(100 - 100 / (1 + avg_gain / avg_loss))
    return result
