"""跨资产:隔夜美股涨幅榜 → 点击下钻 A股细分概念龙头(评分+排名)。

隔夜美股天然无前视:美股 04:00(EDT)收盘,A股 09:30 开盘,昨夜涨跌开盘前已定。
数据源遵循 Sina 主源约定。symbol 大小写敏感(gb_nvda 有效)。

定位:纯展示参考,未经回测验证,不参与选股逻辑、不驱动自动交易。
映射为"概念板块关联"(市场公认),非真·供货关系(免费源做不到订单级)。
A股龙头代码均已与本地 DB 逐个核对名称一致(2026-07-18)。
"""

import re
import time

import requests

from .fetcher import _fetch_sina

# ── A股细分概念 → 龙头(代码, 名称)。代码已与 DB 核对一致 ──────────────
# 概念名是自定义标签(比现有宽板块 SECTOR_DEFS 更细),不要求与之对齐。
CONCEPT_STOCKS = {
    'AI算力·光模块CPO': [
        ('300308', '中际旭创'), ('300502', '新易盛'),
        ('002281', '光迅科技'), ('300394', '天孚通信'),
    ],
    'PCB': [
        ('002463', '沪电股份'), ('002916', '深南电路'),
        ('600183', '生益科技'), ('002938', '鹏鼎控股'),
    ],
    '服务器·算力': [
        ('601138', '工业富联'), ('000977', '浪潮信息'),
        ('603019', '中科曙光'), ('000938', '紫光股份'),
    ],
    '半导体·芯片·设备': [
        ('688981', '中芯国际'), ('002371', '北方华创'), ('688012', '中微公司'),
        ('603986', '兆易创新'), ('688008', '澜起科技'), ('688396', '华润微'),
        ('688521', '芯原股份'), ('688766', '普冉股份'), ('300661', '圣邦股份'),
        ('603501', '豪威集团'),
    ],
    '果链·消费电子': [
        ('002475', '立讯精密'), ('002241', '歌尔股份'),
        ('300433', '蓝思科技'), ('002456', '欧菲光'),
    ],
    '新能源车·锂电池': [
        ('300750', '宁德时代'), ('002594', '比亚迪'), ('601689', '拓普集团'),
        ('002050', '三花智控'), ('002812', '恩捷股份'), ('300014', '亿纬锂能'),
        ('002460', '赣锋锂业'),
    ],
    '人形机器人': [
        ('002472', '双环传动'), ('002527', '新时达'),
        ('300124', '汇川技术'), ('688017', '绿的谐波'),
    ],
    '软件·AI应用': [
        ('688111', '金山办公'), ('002230', '科大讯飞'), ('300496', '中科创达'),
    ],
}

# ── 精选美股池(涨幅榜)。(symbol, 中文名, [关联概念])。 ────────────────
# 概念留空 [] 的标的仍上涨幅榜,但点击下钻会提示"无明确A股概念映射"。
# 中文名写死,不依赖 Sina 返回(其编码常乱)。
US_POOL = [
    # 半导体/AI算力
    ('gb_nvda', '英伟达',   ['AI算力·光模块CPO', 'PCB', '服务器·算力', '半导体·芯片·设备']),
    ('gb_amd',  'AMD',      ['半导体·芯片·设备', '服务器·算力']),
    ('gb_tsm',  '台积电',   ['半导体·芯片·设备']),
    ('gb_avgo', '博通',     ['AI算力·光模块CPO', '半导体·芯片·设备']),
    ('gb_mu',   '美光',     ['半导体·芯片·设备']),
    ('gb_intc', '英特尔',   ['半导体·芯片·设备', '服务器·算力']),
    ('gb_qcom', '高通',     ['半导体·芯片·设备', '果链·消费电子']),
    ('gb_asml', '阿斯麦',   ['半导体·芯片·设备']),
    ('gb_arm',  'ARM',      ['半导体·芯片·设备']),
    ('gb_mrvl', '迈威尔',   ['AI算力·光模块CPO', '半导体·芯片·设备']),
    ('gb_smci', '超微电脑', ['服务器·算力']),
    ('gb_amat', '应用材料', ['半导体·芯片·设备']),
    ('gb_lrcx', '泛林',     ['半导体·芯片·设备']),
    ('gb_txn',  '德州仪器', ['半导体·芯片·设备']),
    ('gb_adi',  '亚德诺',   ['半导体·芯片·设备']),
    # 软件/互联网/云
    ('gb_msft', '微软',     ['软件·AI应用', '服务器·算力']),
    ('gb_googl','谷歌',     ['软件·AI应用']),
    ('gb_meta', 'Meta',     ['软件·AI应用']),
    ('gb_aapl', '苹果',     ['果链·消费电子']),
    ('gb_amzn', '亚马逊',   ['服务器·算力']),
    ('gb_pltr', 'Palantir', ['软件·AI应用']),
    ('gb_orcl', '甲骨文',   ['软件·AI应用', '服务器·算力']),
    ('gb_crm',  'Salesforce', ['软件·AI应用']),
    ('gb_adbe', 'Adobe',    ['软件·AI应用']),
    ('gb_now',  'ServiceNow', ['软件·AI应用']),
    ('gb_snow', 'Snowflake', ['软件·AI应用']),
    ('gb_bidu', '百度',     ['软件·AI应用']),
    ('gb_nflx', '奈飞',     []),
    # 新能源车/机器人
    ('gb_tsla', '特斯拉',   ['新能源车·锂电池', '人形机器人']),
    ('gb_li',   '理想',     ['新能源车·锂电池']),
    ('gb_xpev', '小鹏',     ['新能源车·锂电池']),
    ('gb_nio',  '蔚来',     ['新能源车·锂电池']),
    ('gb_rivn', 'Rivian',   ['新能源车·锂电池']),
    ('gb_fslr', '第一太阳能', []),
    ('gb_gm',   '通用汽车', []),
    ('gb_f',    '福特',     []),
    # 中概(情绪联动为主,不做概念映射)
    ('gb_baba', '阿里巴巴', []),
    ('gb_jd',   '京东',     []),
    ('gb_pdd',  '拼多多',   []),
    ('gb_ntes', '网易',     []),
    ('gb_beke', '贝壳',     []),
    ('gb_tcom', '携程',     []),
    ('gb_coin', 'Coinbase', []),
    # 金融/医药/消费/工业(A股概念关联弱,仅作涨幅榜参考)
    ('gb_jpm',  '摩根大通', []),
    ('gb_gs',   '高盛',     []),
    ('gb_ms',   '摩根士丹利', []),
    ('gb_v',    'Visa',     []),
    ('gb_ma',   '万事达',   []),
    ('gb_lly',  '礼来',     []),
    ('gb_pfe',  '辉瑞',     []),
    ('gb_jnj',  '强生',     []),
    ('gb_mrna', 'Moderna',  []),
    ('gb_unh',  '联合健康', []),
    ('gb_nke',  '耐克',     []),
    ('gb_ko',   '可口可乐', []),
    ('gb_sbux', '星巴克',   []),
    ('gb_mcd',  '麦当劳',   []),
    ('gb_pg',   '宝洁',     []),
    ('gb_xom',  '埃克森美孚', []),
    ('gb_cvx',  '雪佛龙',   []),
    ('gb_ba',   '波音',     []),
    ('gb_cat',  '卡特彼勒', []),
    ('gb_ge',   '通用电气', []),
]

_US_NAME = {s: n for s, n, _c in US_POOL}
_US_CONCEPTS = {s: c for s, n, c in US_POOL}

# 新闻搜索词覆盖:中文名有歧义的美股,用更精准的词搜(避免捞到无关领域)。
# 只放实测确认过的;未列的一律用中文名搜。
# 甲骨文=Oracle,但字面是商代甲骨文字→"甲骨文公司"实测6条全是Oracle公司新闻。
_NEWS_QUERY_OVERRIDE = {
    'gb_orcl': '甲骨文公司',
}

_cache = None
_cache_ts = 0.0
_TTL = 300  # 隔夜行情变动慢,5分钟缓存足够


def fetch_us_quotes():
    """批量取美股池实时行情。返回 {symbol: {name, price, change_pct}}。取不到返回 {}。"""
    symbols = [s for s, _n, _c in US_POOL]
    text = _fetch_sina('https://hq.sinajs.cn/list=' + ','.join(symbols))
    if not text:
        return {}
    out = {}
    for line in text.strip().split('\n'):
        m = re.search(r'hq_str_([\w$]+)="([^"]*)"', line)
        if not m:
            continue
        sym = m.group(1)
        parts = m.group(2).split(',')
        if len(parts) < 3 or not parts[1]:
            continue
        try:
            out[sym] = {
                'name': _US_NAME.get(sym, parts[0]),
                'price': float(parts[1]),
                'change_pct': float(parts[2]) if parts[2] else 0.0,
            }
        except (ValueError, IndexError):
            continue
    return out


def get_overnight_snapshot():
    """涨幅榜:精选美股按隔夜涨跌降序。带 5min 缓存。"""
    global _cache, _cache_ts
    now = time.time()
    if _cache is not None and (now - _cache_ts) < _TTL:
        return _cache
    quotes = fetch_us_quotes()
    rows = []
    for sym, _n, concepts in US_POOL:
        q = quotes.get(sym)
        if not q:
            continue
        rows.append({
            'symbol': sym,
            'name': q['name'],
            'price': q['price'],
            'change_pct': q['change_pct'],
            'concept_count': len(concepts),
        })
    rows.sort(key=lambda x: x['change_pct'], reverse=True)
    snapshot = {
        'us': rows,
        'note': '隔夜美股涨幅榜,概念映射仅供参考,未经回测验证,不参与选股/交易',
    }
    _cache = snapshot
    _cache_ts = now
    return snapshot


def _signals_by_code():
    """{stock_code: [策略名,...]} —— 复用策略信号缓存,给下钻的A股打"有策略买点"标记。"""
    try:
        from ..routes import get_signals_cached
        all_signals = get_signals_cached() or {}
    except Exception:
        return {}
    out = {}
    for strat_name, cands in all_signals.items():
        for c in cands or []:
            code = c.get('stock_code', '')
            if not code:
                continue
            tag = c.get('strategy', strat_name)
            out.setdefault(code, [])
            if tag not in out[code]:
                out[code].append(tag)
    return out


# ── 利好新闻(新浪财经关键词搜索) ────────────────────────────────────
# 纯展示层:帮用户挑美股看的参考,绝不进选股逻辑/交易策略。
# 源:interface.sina.cn 关键词新闻搜索,返回新浪自家域名链接(无跳转重定向)。
_NEWS_URL = 'https://interface.sina.cn/homepage/search.d.json'
_NEWS_HEADERS = {
    'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                   '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'),
    'Referer': 'https://finance.sina.com.cn',
}
_news_cache = {}  # {query: (ts, [items])}
_NEWS_TTL = 1800  # 新闻变动慢,30min 缓存


def _clean_news_title(t):
    return re.sub(r'<[^>]+>', '', t or '').strip()


def fetch_stock_news(query, count=6):
    """按关键词(美股中文名)搜新浪财经新闻。返回 [{title,url,time,media}]。取不到返回 []。"""
    if not query:
        return []
    now = time.time()
    cached = _news_cache.get(query)
    if cached and (now - cached[0]) < _NEWS_TTL:
        return cached[1]
    items = []
    try:
        resp = requests.get(_NEWS_URL,
                            params={'q': query, 't': 'news', 'num': count, 'page': 1},
                            headers=_NEWS_HEADERS, timeout=8)
        if resp.status_code == 200:
            data = resp.json()
            lst = ((data.get('result') or {}).get('list')) or []
            for it in lst[:count]:
                title = _clean_news_title(it.get('title'))
                url = it.get('url', '')
                if not title or not url:
                    continue
                items.append({
                    'title': title,
                    'url': url,
                    'time': it.get('datetime') or it.get('time', ''),
                    'media': it.get('media', ''),
                })
    except Exception:
        items = []
    # 只在成功取到时刷新缓存,失败不覆盖旧数据
    if items:
        _news_cache[query] = (now, items)
        return items
    return cached[1] if cached else []


def _score_concept_stocks(concepts, concept_map):
    """给定概念列表 + 概念→龙头映射表,返回实时评分排序的A股列表(降序)。

    评分 score = 涨跌%*5 + 量比*8(非交易时段量比=0,退化为按涨幅排)。
    落在策略信号里的A股额外标 strategies(仅提示,不改分)。去重(同股多概念只取首个)。
    """
    if not concepts:
        return []
    all_codes = [code for concept in concepts for code, _n in concept_map.get(concept, [])]
    from .fetcher import fetch_quotes_for_codes
    by_code = fetch_quotes_for_codes(all_codes)
    sig_map = _signals_by_code()
    stocks = []
    seen = set()
    for concept in concepts:
        for code, name in concept_map.get(concept, []):
            if code in seen:
                continue
            seen.add(code)
            s = by_code.get(code, {})
            change = float(s.get('涨跌幅', 0) or 0)
            vol_ratio = float(s.get('量比', 0) or 0)
            turnover = float(s.get('换手率', 0) or 0)
            price = float(s.get('最新价', 0) or 0)
            stocks.append({
                'stock_code': code,
                'stock_name': s.get('名称', name),
                'price': price,
                'change_pct': change,
                'vol_ratio': vol_ratio,
                'turnover': turnover,
                'concept': concept,
                'score': round(change * 5 + vol_ratio * 8, 1),
                'strategies': sig_map.get(code, []),
            })
    stocks.sort(key=lambda x: x['score'], reverse=True)
    return stocks


def _concept_us_signals(concepts, quotes):
    """给定概念列表和当前美股行情，计算每个概念的美股信号。

    信号 = 该概念下所有映射美股的平均涨跌幅(%)。
    与回测用的同一口径：概念内US股票等权均值。
    """
    signals = {}
    for concept in concepts:
        contribs = [
            quotes[sym]['change_pct']
            for sym, sym_concepts in _US_CONCEPTS.items()
            if concept in sym_concepts and sym in quotes
        ]
        if contribs:
            signals[concept] = round(sum(contribs) / len(contribs), 2)
    return signals


def get_symbol_drilldown(symbol):
    """点击某美股 → 其关联A股细分概念龙头,实时评分+排名。

    纯展示,未经回测验证,不驱动交易。
    返回 {symbol, name, change_pct, concepts, concept_signals, stocks:[...按score降序], news, note}。
    无概念映射的标的返回空 concepts + 空 stocks(仍返回新闻)。
    """
    quotes = fetch_us_quotes()
    q = quotes.get(symbol, {})
    concepts = _US_CONCEPTS.get(symbol, [])
    us_name = q.get('name', _US_NAME.get(symbol, symbol))

    # 概念级美股信号（已与回测同口径：概念内等权均值）
    concept_signals = _concept_us_signals(concepts, quotes)

    news = fetch_stock_news(_NEWS_QUERY_OVERRIDE.get(symbol, us_name))
    stocks = _score_concept_stocks(concepts, CONCEPT_STOCKS)

    # 将概念信号附到每只A股
    for s in stocks:
        s['us_signal'] = concept_signals.get(s['concept'])

    return {
        'symbol': symbol,
        'name': us_name,
        'change_pct': q.get('change_pct', 0),
        'concepts': concepts,
        'concept_signals': concept_signals,
        'stocks': stocks,
        'news': news,
        'note': '概念映射仅供参考,未经回测验证,不参与选股逻辑、不驱动自动交易',
    }


# ══════════════════════════════════════════════════════════════════════
# 商品(黄金/期货)→ A股概念龙头。与美股同一套模式:行情榜→下钻评分+新闻。
# 定位同美股:纯展示参考,未经回测验证,不参与选股逻辑、不驱动自动交易。
#
# 时点诚实:
#  - 国际盘(伦敦金/纽约原油/COMEX铜)是隔夜收盘,A股开盘前已定,领先、无前视。
#  - 国内期货夜盘领先次日;但日盘 09:00-15:00 与A股同步,不领先。卡片如实标注。
# A股龙头代码均已与本地 DB 逐个核对名称一致(2026-07-18,银泰黄金已更名山金国际、
# 兴业矿业已更名兴业银锡,均按DB真名保留)。
# ══════════════════════════════════════════════════════════════════════

# ── 商品概念 → A股龙头(代码, 名称)。代码已与 DB 核对一致 ──────────────
COMMODITY_STOCKS = {
    '黄金': [
        ('600547', '山东黄金'), ('600489', '中金黄金'), ('600988', '赤峰黄金'),
        ('601899', '紫金矿业'), ('002155', '湖南黄金'), ('000975', '山金国际'),
    ],
    '白银': [
        ('000603', '盛达资源'), ('000426', '兴业银锡'),
    ],
    '铜': [
        ('600362', '江西铜业'), ('000630', '铜陵有色'), ('000878', '云南铜业'),
    ],
    '铝': [
        ('601600', '中国铝业'), ('000807', '云铝股份'),
        ('000933', '神火股份'), ('002532', '天山铝业'),
    ],
    '钢铁': [
        ('600019', '宝钢股份'), ('000932', '华菱钢铁'), ('600282', '南钢股份'),
        ('002110', '三钢闽光'), ('000709', '河钢股份'),
    ],
    '煤炭': [
        ('601088', '中国神华'), ('601225', '陕西煤业'), ('600188', '兖矿能源'),
        ('000983', '山西焦煤'), ('601699', '潞安环能'),
    ],
    '石油': [
        ('601857', '中国石油'), ('600028', '中国石化'), ('600938', '中国海油'),
        ('600346', '恒力石化'), ('002493', '荣盛石化'),
    ],
    '锂': [
        ('002460', '赣锋锂业'), ('002466', '天齐锂业'), ('000792', '盐湖股份'),
        ('002756', '永兴材料'), ('002738', '中矿资源'),
    ],
    '镍钴': [
        ('603799', '华友钴业'), ('002340', '格林美'),
    ],
    '锡': [
        ('000960', '锡业股份'),
    ],
    '工业硅': [
        ('603260', '合盛硅业'),
    ],
    '不锈钢': [
        ('000825', '太钢不锈'),
    ],
}

# ── 商品池。(symbol, 中文名, 格式'hf'国际/'nf'国内, [关联概念], 新闻搜索词) ──
# hf 国际盘:隔夜收盘,领先A股开盘,无前视。nf 国内期货:日盘与A股同步。
COMMODITY_POOL = [
    # 国际盘(hf):隔夜收盘,A股开盘前已定 —— 领先信号
    ('hf_XAU', '伦敦金',   'hf', ['黄金'], '黄金'),
    ('hf_XAG', '伦敦银',   'hf', ['白银'], '白银'),
    ('hf_CL',  '纽约原油', 'hf', ['石油'], '原油'),
    ('hf_HG',  'COMEX铜', 'hf', ['铜'],   '铜价'),
    # 国内期货(nf):日盘与A股同步,夜盘领先次日 —— 强弱参考
    ('nf_AU0', '沪金',     'nf', ['黄金'], '黄金'),
    ('nf_AG0', '沪银',     'nf', ['白银'], '白银'),
    ('nf_CU0', '沪铜',     'nf', ['铜'],   '铜价'),
    ('nf_AL0', '沪铝',     'nf', ['铝'],   '电解铝'),
    ('nf_NI0', '沪镍',     'nf', ['镍钴'], '镍价'),
    ('nf_SN0', '沪锡',     'nf', ['锡'],   '锡价'),
    ('nf_SS0', '不锈钢',   'nf', ['不锈钢'], '不锈钢'),
    ('nf_RB0', '螺纹钢',   'nf', ['钢铁'], '螺纹钢'),
    ('nf_HC0', '热轧卷板', 'nf', ['钢铁'], '热轧卷板'),
    ('nf_I0',  '铁矿石',   'nf', ['钢铁'], '铁矿石'),
    ('nf_J0',  '焦炭',     'nf', ['煤炭'], '焦炭'),
    ('nf_JM0', '焦煤',     'nf', ['煤炭'], '焦煤'),
    ('nf_SC0', '上海原油', 'nf', ['石油'], '原油'),
    ('nf_LC0', '碳酸锂',   'nf', ['锂'],   '碳酸锂'),
    ('nf_SI0', '工业硅',   'nf', ['工业硅'], '工业硅'),
]

_COMMOD_NAME = {s: n for s, n, _f, _c, _q in COMMODITY_POOL}
_COMMOD_META = {s: {'name': n, 'fmt': f, 'concepts': c, 'news_q': q}
                for s, n, f, c, q in COMMODITY_POOL}

_commod_cache = None
_commod_cache_ts = 0.0
_COMMOD_TTL = 300  # 商品行情变动慢,5min缓存


def _parse_commodity(sym, fmt, parts):
    """按格式解析商品行情。返回 {price, change_pct} 或 None。
    hf(国际,14-15字段):[0]=现价,[7]=昨收。
    nf(国内,44字段):[0]=名称,[8]=最新价,[10]=昨结算。
    """
    try:
        if fmt == 'hf':
            price = float(parts[0]) if parts[0] else 0.0
            prev = float(parts[7]) if len(parts) > 7 and parts[7] else 0.0
        else:  # nf
            price = float(parts[8]) if len(parts) > 8 and parts[8] else 0.0
            prev = float(parts[10]) if len(parts) > 10 and parts[10] else 0.0
        if price <= 0 or prev <= 0:
            return None
        return {'price': price, 'change_pct': round((price - prev) / prev * 100, 2)}
    except (ValueError, IndexError):
        return None


def fetch_commodity_quotes():
    """批量取商品池实时行情。返回 {symbol: {name, price, change_pct, fmt}}。取不到返回 {}。"""
    symbols = [s for s, _n, _f, _c, _q in COMMODITY_POOL]
    text = _fetch_sina('https://hq.sinajs.cn/list=' + ','.join(symbols))
    if not text:
        return {}
    out = {}
    for line in text.strip().split('\n'):
        m = re.search(r'hq_str_([\w$]+)="([^"]*)"', line)
        if not m:
            continue
        sym = m.group(1)
        meta = _COMMOD_META.get(sym)
        if not meta:
            continue
        parts = m.group(2).split(',')
        parsed = _parse_commodity(sym, meta['fmt'], parts)
        if not parsed:
            continue
        out[sym] = {
            'name': meta['name'],
            'price': parsed['price'],
            'change_pct': parsed['change_pct'],
            'fmt': meta['fmt'],
        }
    return out


def get_commodity_snapshot():
    """商品涨跌榜:黄金/期货按涨跌降序。带 5min 缓存。"""
    global _commod_cache, _commod_cache_ts
    now = time.time()
    if _commod_cache is not None and (now - _commod_cache_ts) < _COMMOD_TTL:
        return _commod_cache
    quotes = fetch_commodity_quotes()
    rows = []
    for sym, _n, fmt, concepts, _q in COMMODITY_POOL:
        c = quotes.get(sym)
        if not c:
            continue
        rows.append({
            'symbol': sym,
            'name': c['name'],
            'price': c['price'],
            'change_pct': c['change_pct'],
            'concept_count': len(concepts),
            'session': 'intl' if fmt == 'hf' else 'domestic',
        })
    rows.sort(key=lambda x: x['change_pct'], reverse=True)
    snapshot = {
        'items': rows,
        'note': '国际盘(伦敦金/纽约原油/COMEX铜)隔夜收盘领先A股;国内期货日盘与A股同步,仅作强弱参考。未经回测验证,不参与选股/交易。',
    }
    _commod_cache = snapshot
    _commod_cache_ts = now
    return snapshot


def get_commodity_drilldown(symbol):
    """点击某商品 → 关联A股概念龙头,实时评分+排名 + 相关新闻。纯展示。"""
    meta = _COMMOD_META.get(symbol, {})
    concepts = meta.get('concepts', [])
    name = meta.get('name', symbol)

    quotes = fetch_commodity_quotes()
    c = quotes.get(symbol, {})

    news = fetch_stock_news(meta.get('news_q') or name)
    stocks = _score_concept_stocks(concepts, COMMODITY_STOCKS)

    return {
        'symbol': symbol,
        'name': name,
        'change_pct': c.get('change_pct', 0),
        'concepts': concepts,
        'stocks': stocks,
        'news': news,
        'note': '商品→A股为概念关联(市场公认),非真·供货关系。未经回测验证,不参与选股逻辑、不驱动自动交易。',
    }


# ── FX USDCNH 实盘展示 ──────────────────────────────────────────────────────
_fx_cache = None
_fx_cache_ts = 0.0
_FX_TTL = 300  # 5min


def get_fx_snapshot():
    """美元/人民币实时汇率。仅展示，未经回测验证，不参与打分决策。"""
    global _fx_cache, _fx_cache_ts
    now = time.time()
    if _fx_cache is not None and (now - _fx_cache_ts) < _FX_TTL:
        return _fx_cache
    try:
        text = _fetch_sina('https://hq.sinajs.cn/list=fx_susdcnh')
        m = re.search(r'hq_str_fx_susdcnh="([^"]*)"', text or '')
        if m:
            parts = m.group(1).split(',')
            rate = None
            for p in parts[:5]:
                try:
                    v = float(p)
                    if 6.0 <= v <= 9.0:
                        rate = v
                        break
                except ValueError:
                    continue
            if rate is not None:
                prev = None
                for p in parts[5:10]:
                    try:
                        v = float(p)
                        if 6.0 <= v <= 9.0:
                            prev = v
                            break
                    except ValueError:
                        continue
                prev = prev or rate
                change = round(rate - prev, 4)
                # USDCNH 升 → CNY 贬值；USDCNH 降 → CNY 升值
                if change < -0.001:
                    direction, color_key = '人民币升值', 'green'
                elif change > 0.001:
                    direction, color_key = '人民币贬值', 'red'
                else:
                    direction, color_key = '基本持平', 'neutral'
                result = {
                    'rate': round(rate, 4),
                    'change': change,
                    'direction': direction,
                    'color_key': color_key,
                    'note': '未经回测验证，仅作展示，不参与打分决策',
                }
                _fx_cache = result
                _fx_cache_ts = now
                return result
    except Exception:
        pass
    return _fx_cache  # 失败返回旧缓存
