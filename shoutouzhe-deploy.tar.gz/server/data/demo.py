import random
from datetime import datetime, timedelta

DEMO_INDICES = [
    {'name': '上证指数', 'code': '000001', 'price': 3996.16, 'change_pct': -1.17, 'change': -47.30, 'volume': 285000000, 'amount': 356000000000},
    {'name': '深证成指', 'code': '399001', 'price': 13456.32, 'change_pct': 0.65, 'change': 87.30, 'volume': 345000000, 'amount': 420000000000},
    {'name': '创业板指', 'code': '399006', 'price': 2856.70, 'change_pct': 1.12, 'change': 31.60, 'volume': 112000000, 'amount': 168000000000},
]

def _random_change():
    return round(random.uniform(-5, 5), 2)

DEMO_STOCKS = [
    ('600519', '贵州茅台', 1680.50),
    ('000858', '五粮液', 73.40),
    ('601318', '中国平安', 48.60),
    ('600036', '招商银行', 38.20),
    ('000333', '美的集团', 62.80),
    ('002415', '海康威视', 32.50),
    ('600276', '恒瑞医药', 45.80),
    ('300750', '宁德时代', 198.60),
    ('002594', '比亚迪', 268.40),
    ('601012', '隆基绿能', 22.30),
    ('600900', '长江电力', 28.50),
    ('000001', '平安银行', 11.80),
    ('603259', '药明康德', 52.30),
    ('300124', '汇川技术', 62.40),
    ('002475', '立讯精密', 32.80),
    ('000725', '京东方A', 4.20),
    ('601888', '中国中免', 88.50),
    ('600809', '山西汾酒', 225.60),
    ('300274', '阳光电源', 88.90),
    ('002230', '科大讯飞', 48.30),
    ('688981', '中芯国际', 52.40),
    ('600030', '中信证券', 22.60),
    ('000063', '中兴通讯', 28.70),
    ('300059', '东方财富', 16.80),
    ('002142', '宁波银行', 26.40),
    ('601899', '紫金矿业', 16.20),
    ('600585', '海螺水泥', 25.30),
    ('000338', '潍柴动力', 14.80),
    ('600031', '三一重工', 17.90),
    ('002352', '顺丰控股', 42.60),
    ('601857', '中国石油', 8.20),
    ('600028', '中国石化', 6.50),
    ('601088', '中国神华', 36.70),
    ('600887', '伊利股份', 28.90),
    ('300015', '爱尔眼科', 18.60),
    ('603288', '海天味业', 42.30),
    ('002304', '洋河股份', 108.50),
    ('000568', '泸州老窖', 189.30),
    ('600436', '片仔癀', 235.40),
    ('688036', '传音控股', 142.80),
    ('002714', '牧原股份', 42.50),
    ('300498', '温氏股份', 19.30),
    ('601166', '兴业银行', 17.80),
    ('600048', '保利发展', 9.60),
    ('000002', '万科A', 8.90),
    ('601398', '工商银行', 6.20),
    ('601939', '建设银行', 7.80),
    ('601288', '农业银行', 4.80),
    ('601328', '交通银行', 6.90),
    ('002049', '紫光国微', 72.30),
]

def get_demo_stocks():
    stocks = []
    for code, name, base in DEMO_STOCKS:
        change = _random_change()
        price = round(base * (1 + change / 100), 2)
        stocks.append({
            '代码': code, '名称': name,
            '最新价': price, '涨跌幅': change,
            '涨跌额': round(price - base, 2),
            '成交量': random.randint(10000, 500000),
            '成交额': random.randint(1000000, 500000000),
            '换手率': round(random.uniform(0.1, 5), 2),
            '量比': round(random.uniform(0.5, 2.5), 2),
        })
    return stocks

def get_demo_sectors():
    sectors = ['半导体', '白酒', '银行', '新能源', '医药', '电力', '消费电子', '汽车', '证券', '煤炭', '食品饮料', '通信']
    return [{'name': n, 'change_pct': round(random.uniform(-2, 3), 2)} for n in sectors]

_kline_cache = {}

def get_demo_kline(code, days=60):
    cache_key = f'{code}_{days}'
    if cache_key in _kline_cache:
        return _kline_cache[cache_key]

    base_prices = {s[0]: s[2] for s in DEMO_STOCKS}
    base = base_prices.get(code, 50)
    klines = []
    price = base * (0.9 + hash(code) % 30 / 100)
    rng = random.Random(hash(code))
    for i in range(days):
        change = rng.uniform(-0.025, 0.025)
        close = round(price * (1 + change), 2)
        high = round(close * (1 + rng.uniform(0, 0.015)), 2)
        low = round(close * (1 - rng.uniform(0, 0.015)), 2)
        open_p = round(low + rng.uniform(0, high - low), 2)
        date = (datetime.now() - timedelta(days=days - i)).strftime('%Y-%m-%d')
        klines.append({
            'date': date, 'open': open_p, 'close': close,
            'high': high, 'low': low,
            'volume': rng.randint(50000, 500000)
        })
        price = close
    _kline_cache[cache_key] = klines
    return klines
