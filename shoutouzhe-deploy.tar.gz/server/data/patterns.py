def _body(open_p, close):
    return abs(close - open_p)


def _upper_shadow(high, open_p, close):
    return high - max(open_p, close)


def _lower_shadow(open_p, close, low):
    return min(open_p, close) - low


def _range(high, low):
    return high - low


def _is_green(open_p, close):
    return close > open_p


def _is_red(open_p, close):
    return close < open_p


def doji(k, threshold=0.1):
    r = _range(k['high'], k['low'])
    if r == 0:
        return None
    if _body(k['open'], k['close']) <= r * threshold:
        return '十字星'
    return None


def hammer(k):
    body = _body(k['open'], k['close'])
    r = _range(k['high'], k['low'])
    if r == 0 or body == 0:
        return None
    lower = _lower_shadow(k['open'], k['close'], k['low'])
    upper = _upper_shadow(k['high'], k['open'], k['close'])
    if lower >= body * 2 and upper <= body * 0.5:
        return '锤子线'
    return None


def shooting_star(k):
    body = _body(k['open'], k['close'])
    r = _range(k['high'], k['low'])
    if r == 0 or body == 0:
        return None
    upper = _upper_shadow(k['high'], k['open'], k['close'])
    lower = _lower_shadow(k['open'], k['close'], k['low'])
    if upper >= body * 2 and lower <= body * 0.5:
        return '射击之星'
    return None


def bullish_engulfing(k1, k2):
    if not (_is_red(k1['open'], k1['close']) and _is_green(k2['open'], k2['close'])):
        return None
    body1 = _body(k1['open'], k1['close'])
    body2 = _body(k2['open'], k2['close'])
    if k2['open'] <= k1['close'] and k2['close'] >= k1['open'] and body2 > body1:
        return '出水芙蓉'
    return None


def bearish_engulfing(k1, k2):
    if not (_is_green(k1['open'], k1['close']) and _is_red(k2['open'], k2['close'])):
        return None
    body1 = _body(k1['open'], k1['close'])
    body2 = _body(k2['open'], k2['close'])
    if k2['open'] >= k1['close'] and k2['close'] <= k1['open'] and body2 > body1:
        return '乌云盖顶'
    return None


def dark_cloud_cover(k1, k2):
    if not (_is_green(k1['open'], k1['close']) and _is_red(k2['open'], k2['close'])):
        return None
    if k2['open'] > k1['high'] and k2['close'] < (k1['open'] + k1['close']) / 2:
        return '乌云盖顶'
    return None


def piercing_line(k1, k2):
    if not (_is_red(k1['open'], k1['close']) and _is_green(k2['open'], k2['close'])):
        return None
    if k2['open'] < k1['low'] and k2['close'] > (k1['open'] + k1['close']) / 2:
        return '刺透形态'
    return None


def morning_star(k1, k2, k3):
    if not _is_red(k1['open'], k1['close']):
        return None
    body1 = _body(k1['open'], k1['close'])
    body3 = _body(k3['open'], k3['close'])
    if body1 < _range(k1['high'], k1['low']) * 0.3:
        return None
    if not _is_green(k3['open'], k3['close']):
        return None
    if not (k2['close'] < k1['close'] and k3['open'] > k2['close']):
        return None
    if k3['close'] > (k1['open'] + k1['close']) / 2:
        return '早晨之星'
    return None


def evening_star(k1, k2, k3):
    if not _is_green(k1['open'], k1['close']):
        return None
    body1 = _body(k1['open'], k1['close'])
    if body1 < _range(k1['high'], k1['low']) * 0.3:
        return None
    if not _is_red(k3['open'], k3['close']):
        return None
    if not (k2['close'] > k1['close'] and k3['open'] < k2['close']):
        return None
    if k3['close'] < (k1['open'] + k1['close']) / 2:
        return '黄昏之星'
    return None


def three_white_soldiers(k1, k2, k3):
    for k in [k1, k2, k3]:
        if not _is_green(k['open'], k['close']):
            return None
    if k2['close'] > k1['close'] and k3['close'] > k2['close']:
        return '红三兵'
    return None


def three_black_crows(k1, k2, k3):
    for k in [k1, k2, k3]:
        if not _is_red(k['open'], k['close']):
            return None
    if k2['close'] < k1['close'] and k3['close'] < k2['close']:
        return '三只乌鸦'
    return None


_PATTERN_SPECS = [
    ('bullish', [morning_star, three_white_soldiers], 3),
    ('bearish', [evening_star, three_black_crows], 3),
    ('bullish', [bullish_engulfing, piercing_line], 2),
    ('bearish', [bearish_engulfing, dark_cloud_cover], 2),
    ('bullish', [hammer], 1),
    ('bearish', [shooting_star], 1),
    ('neutral', [doji], 1),
]


def detect_all(klines):
    if len(klines) < 3:
        return []
    results = []
    for cat, funcs, window in _PATTERN_SPECS:
        for i in range(window - 1, len(klines)):
            if window == 1:
                pattern = funcs[0](klines[i])
            elif window == 2:
                pattern = None
                for fn in funcs:
                    pattern = fn(klines[i - 1], klines[i])
                    if pattern:
                        break
            else:
                pattern = None
                for fn in funcs:
                    pattern = fn(klines[i - 2], klines[i - 1], klines[i])
                    if pattern:
                        break
            if pattern:
                results.append({
                    'date': klines[i]['date'],
                    'pattern': pattern,
                    'type': cat,
                })
    return results
