import re
import time
import threading
from datetime import datetime

import requests

from .cache import cache

session = requests.Session()
session.headers.update({
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
    'Referer': 'https://finance.sina.com.cn'
})

SINA_LIST_URL = 'http://vip.stock.finance.sina.com.cn/quotes_service/api/json_v2.php/Market_Center.getHQNodeData'
SINA_KLINE_URL = 'https://quotes.sina.cn/cn/api/json_v2.php/CN_MarketData.getKLineData'
SINA_NEWS_URL = 'https://feed.mix.sina.com.cn/api/roll/get'
TENCENT_QUOTE_URL = 'http://qt.gtimg.cn/q='

_stock_list_lock = threading.Lock()
_stock_list_cache = None
_stock_list_ts = 0.0
_STOCK_LIST_TTL = 30  # 30s — refresh live prices every 30s during trading


def is_trading_day():
    now = datetime.now()
    return now.weekday() < 5


def is_trading_time():
    now = datetime.now()
    if not is_trading_day():
        return False
    t = now.hour * 100 + now.minute
    # 上午 9:30-11:30, 下午 13:00-15:00
    return (930 <= t <= 1130) or (1300 <= t <= 1500)


def is_lunch_break():
    """Check if currently in lunch break (11:30-13:00 on trading day)."""
    now = datetime.now()
    if not is_trading_day():
        return False
    t = now.hour * 100 + now.minute
    return 1130 < t < 1300


# ── Helpers ─────────────────────────────────────────────────────────

def _safe_float(val):
    try:
        return float(val)
    except (ValueError, TypeError):
        return 0.0


def _board_limit(code):
    """单日涨跌停幅度(小数)。用于判定'物理上不可能的单日跳变'=除权接缝。
    科创/创业 20%,北交所 30%,主板 10%。ST 未细分(除权送转缺口远大于阈值,不影响)。"""
    code = str(code)
    if code.startswith(('688', '689', '300', '301')):
        return 0.20
    if code.startswith(('8', '9', '4')):   # 北交所 83/87/92/430...
        return 0.30
    return 0.10


# 除权检测容忍度: 容忍收盘价 2 位小数舍入误差
QFQ_TOLERANCE = 0.005

def _apply_qfq(bars, code):
    """只读时前复权:检测除权接缝(单日 close 跳变超过本板块涨跌停),
    把接缝之前的历史 bar 按接缝比例反向缩放,消除K线悬崖。
    最新一根保持真实价格。因子由 Sina 自身数据重建(close 比值),
    近似:会把除权当天的真实日内涨跌吸收进因子(误差 ≤ 涨跌停幅度)。
    volume 保持原值。bars 需按时间升序。"""
    n = len(bars)
    if n < 2:
        return bars
    limit = _board_limit(code)
    thr = limit + QFQ_TOLERANCE  # 容忍收盘价 2 位小数舍入
    mult = [1.0] * n
    cum = 1.0
    for i in range(n - 1, 0, -1):
        prev_c = bars[i - 1].get('close', 0)
        cur_c = bars[i].get('close', 0)
        if prev_c and cur_c > 0:
            ratio = cur_c / prev_c
            if abs(ratio - 1.0) > thr:   # 超过涨跌停 = 除权接缝(或缩股)
                cum *= ratio
        mult[i - 1] = cum
    if all(m == 1.0 for m in mult):
        return bars   # 无接缝,原样返回
    out = []
    for i, b in enumerate(bars):
        m = mult[i]
        if m == 1.0:
            out.append(b)
            continue
        nb = dict(b)
        for k in ('open', 'high', 'low', 'close'):
            if nb.get(k):
                nb[k] = round(nb[k] * m, 2)
        out.append(nb)
    return out


def _fetch_sina(url, timeout=5):
    try:
        resp = requests.get(url, timeout=timeout, headers={
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
            'Referer': 'https://finance.sina.com.cn'
        })
        resp.encoding = 'gbk'
        if resp.status_code == 200 and resp.text.strip():
            return resp.text
    except requests.RequestException as e:
        print(f"[WARN] Sina API 请求失败: {e}")
    return None


def _fetch_sina_json(url, params=None, timeout=8):
    try:
        resp = session.get(url, params=params, timeout=timeout)
        resp.encoding = 'gbk'
        if resp.status_code == 200 and resp.text.strip():
            return resp.json()
    except requests.RequestException as e:
        print(f"[WARN] Sina JSON API 请求失败: {e}")
    except ValueError as e:
        print(f"[WARN] Sina JSON 解析失败: {e}")
    return None


# ── Stock list via Sina pagination ──────────────────────────────────

def get_stock_list_from_db():
    """Read all stocks from local DB with latest kline close — instant, no API call."""
    try:
        from ..db import get_db
        db = get_db()
        try:
            rows = db.execute("""
                SELECT s.code, s.name, s.market, s.board, s.sector, s.last_sync,
                       k.close as kline_close, k.prev_close as kline_prev_close,
                       k.volume as kline_volume
                FROM stocks s
                LEFT JOIN (
                    SELECT stock_code, close, volume,
                           LAG(close) OVER (PARTITION BY stock_code ORDER BY date) AS prev_close,
                           ROW_NUMBER() OVER (PARTITION BY stock_code ORDER BY date DESC) AS rn
                    FROM stock_kline_daily
                ) k ON s.code = k.stock_code AND k.rn = 1
                ORDER BY s.code
            """).fetchall()
        finally:
            db.close()
        if not rows:
            return []
        results = []
        for r in rows:
            close_price = r['kline_close'] or 0
            prev_close = r['kline_prev_close'] or 0
            if close_price > 0 and prev_close > 0:
                change_pct = round((close_price - prev_close) / prev_close * 100, 2)
                change_amt = round(close_price - prev_close, 2)
                # 除权除息接缝:DB 前收未复权,机械算出的跌幅超本板块涨跌停=假异动。
                # 交易时段 overlay_live_prices 会用 Sina 除权后前收覆盖为真实涨跌幅;
                # 非交易时段无真实前收可依,近似置 0,避免污染异动监控。
                if abs(change_pct) > (_board_limit(r['code']) * 100 + 0.5):
                    change_pct = 0
                    change_amt = 0
            else:
                change_pct = 0
                change_amt = 0
            results.append({
                '代码': r['code'],
                '名称': r['name'],
                '最新价': round(close_price, 2),
                '涨跌幅': change_pct,
                '涨跌额': change_amt,
                '成交量': r['kline_volume'] or 0,
                '成交额': 0,
                '换手率': 0,
                '量比': 0,
            })
        return results
    except Exception:
        return []


def overlay_live_prices(stocks):
    """Overlay real-time Sina quotes onto stock list entries. Mutates in-place."""
    if not stocks or len(stocks) < 1:
        return
    if not is_trading_day():
        return
    # No time restriction: Sina returns today's closing prices throughout the day and after-hours
    codes = [s['代码'] for s in stocks]
    code_map = {s['代码']: s for s in stocks}
    # Sina batch quote supports up to ~800 codes per request
    for i in range(0, len(codes), 800):
        chunk = codes[i:i+800]
        symbols = []
        for c in chunk:
            p = _kline_prefix(c)
            symbols.append(f'{p}{c}')
        text = _fetch_sina('https://hq.sinajs.cn/list=' + ','.join(symbols))
        if not text:
            continue
        for line in text.strip().split('\n'):
            m = re.search(r'hq_str_(\w+)="([^"]*)"', line)
            if not m:
                # Try alternate pattern
                m = re.search(r'var hq_str_(\w+)="([^"]*)"', line)
            if m:
                code_key = m.group(1)
                parts = m.group(2).split(',')
                numeric_code = code_key[2:] if len(code_key) > 2 else code_key
                s = code_map.get(numeric_code)
                if not s and code_key.startswith('sz'):
                    s = code_map.get(code_key[2:])
                if s and len(parts) >= 4:
                    try:
                        preclose = float(parts[2]) if parts[2] else 0
                        current = float(parts[3]) if parts[3] else 0
                        s['最新价'] = current if current > 0 else preclose
                        if preclose > 0 and current > 0:
                            s['涨跌幅'] = round((current - preclose) / preclose * 100, 2)
                            s['涨跌额'] = round(current - preclose, 2)
                        prev_vol = float(s.get('成交量', 0))  # DB value = prev day volume
                        today_vol = float(parts[8]) if len(parts) > 8 and parts[8] else 0
                        s['成交量'] = today_vol
                        # approximate volume ratio: (today vol/min) / (prev day vol/240min)
                        if prev_vol > 0 and today_vol > 0:
                            _now = datetime.now()
                            _t = _now.hour * 60 + _now.minute
                            if _t >= 9 * 60 + 30:
                                _mins = min(_t - 9 * 60 - 30, 120)
                                if _t >= 13 * 60:
                                    _mins = 120 + min(_t - 13 * 60, 120)
                                _mins = max(_mins, 1)
                                s['量比'] = round((today_vol / _mins) / (prev_vol / 240), 2)
                    except (ValueError, IndexError):
                        pass


def fetch_quotes_for_codes(codes):
    """Fetch real-time quotes for a small set of codes directly (no cache).
    Uses Sina hq.sinajs.cn for price/change, Tencent qt.gtimg.cn for 换手率/量比.
    Returns {code: {'最新价', '涨跌幅', '涨跌额', '成交量', '换手率', '量比'}}.
    """
    if not codes:
        return {}
    result = {c: {'最新价': 0, '涨跌幅': 0, '涨跌额': 0, '成交量': 0}
              for c in codes}

    # ── Sina: price / change / volume ──────────────────────────────────
    symbols = [f'{_kline_prefix(c)}{c}' for c in codes]
    text = _fetch_sina('https://hq.sinajs.cn/list=' + ','.join(symbols))
    if text:
        for line in text.strip().split('\n'):
            m = re.search(r'hq_str_(\w+)="([^"]*)"', line)
            if not m:
                continue
            key = m.group(1)
            code = key[2:] if len(key) > 2 else key
            if code not in result:
                continue
            parts = m.group(2).split(',')
            if len(parts) < 9:
                continue
            try:
                preclose = float(parts[2]) if parts[2] else 0
                current  = float(parts[3]) if parts[3] else 0
                volume   = float(parts[8]) if parts[8] else 0
                price = current if current > 0 else preclose
                chg   = round((current - preclose) / preclose * 100, 2) if preclose > 0 and current > 0 else 0
                result[code].update({
                    '最新价': price,
                    '涨跌幅': chg,
                    '涨跌额': round(current - preclose, 2) if preclose > 0 and current > 0 else 0,
                    '成交量': volume,
                })
            except (ValueError, IndexError):
                pass

    return result


def get_stock_list():
    global _stock_list_cache, _stock_list_ts
    now = time.time()
    if _stock_list_cache is not None and (now - _stock_list_ts) < _STOCK_LIST_TTL:
        return _stock_list_cache

    # During lunch break, keep the pre-lunch live prices — don't refresh from DB
    if is_lunch_break() and _stock_list_cache is not None:
        return _stock_list_cache

    with _stock_list_lock:
        if _stock_list_cache is not None and (now - _stock_list_ts) < _STOCK_LIST_TTL:
            return _stock_list_cache

        if is_lunch_break() and _stock_list_cache is not None:
            return _stock_list_cache

        # 1. DB first
        stocks = get_stock_list_from_db()
        if stocks:
            # Overlay live prices during trading hours
            overlay_live_prices(stocks)
            _stock_list_cache = stocks
            _stock_list_ts = time.time()
            return stocks

        # 2. Sina API fallback
        stocks = _fetch_sina_stocks()
        if not stocks:
            stocks = _fetch_stock_list_fallback()

        _stock_list_cache = stocks
        _stock_list_ts = time.time()
        return stocks


def _fetch_sina_stocks():
    """Paginate Sina stock list — fast HTTP, no heavy dependencies."""
    results = []
    trading = is_trading_time()

    for node in ('sh_a', 'sz_a'):
        for page in range(1, 10):
            data = _fetch_sina_json(SINA_LIST_URL, params={
                'page': page, 'num': 100, 'sort': 'symbol', 'asc': 1, 'node': node
            }, timeout=10)
            if not data:
                break
            for s in data:
                code = s.get('code', '')
                name = s.get('name', '')
                price = _safe_float(s.get('trade', 0))
                preclose = _safe_float(s.get('settlement', 0))

                # Use preclose if current price is 0 (pre-market)
                if price <= 0 and preclose > 0:
                    price = preclose

                if price <= 0:
                    continue
                if 'ST' in name or '退' in name:
                    continue
                # Exclude ChiNext (30xxxx), STAR (68xxxx), BJ (8xxxx/9xxxx)
                if code.startswith(('30', '68', '8', '9')):
                    continue

                volume = _safe_float(s.get('volume', 0))
                bid = _safe_float(s.get('buy', 0))
                ask = _safe_float(s.get('sell', 0))
                # Detect suspended: volume=0 + bid/ask=0 during trading hours
                if trading and volume == 0 and bid == 0 and ask == 0:
                    continue

                results.append({
                    '代码': code,
                    '名称': name,
                    '最新价': price,
                    '涨跌幅': _safe_float(s.get('changepercent', 0)),
                    '涨跌额': _safe_float(s.get('pricechange', 0)),
                    '成交量': volume,
                    '成交额': _safe_float(s.get('amount', 0)),
                    '换手率': _safe_float(s.get('turnoverratio', 0)),
                    '量比': 0,
                })
    return results


def _fetch_stock_list_fallback():
    """AKShare fallback if Sina pagination fails."""
    try:
        import akshare as ak
        df = ak.stock_zh_a_spot()
        if df is None or df.empty:
            return _demo_stocks()
        results = []
        trading = is_trading_time()
        for _, row in df.iterrows():
            code = str(row.get('代码', '')).replace('sh', '').replace('sz', '').replace('bj', '')
            name = str(row.get('名称', ''))
            price = _safe_float(row.get('最新价', 0))
            if price <= 0:
                price = _safe_float(row.get('昨收', 0))
            if price <= 0 or 'ST' in name or '退' in name:
                continue
            if code.startswith(('83', '87', '92', '30', '68')):
                continue
            vol = _safe_float(row.get('成交量', 0))
            bid = _safe_float(row.get('买入', 0))
            ask = _safe_float(row.get('卖出', 0))
            if trading and vol == 0 and bid == 0 and ask == 0:
                continue
            results.append({
                '代码': code, '名称': name, '最新价': price,
                '涨跌幅': _safe_float(row.get('涨跌幅', 0)),
                '涨跌额': _safe_float(row.get('涨跌额', 0)),
                '成交量': vol, '成交额': _safe_float(row.get('成交额', 0)),
                '换手率': _safe_float(row.get('换手率', 0)), '量比': 0,
            })
        return results
    except:
        return _demo_stocks()


def _demo_stocks():
    from .demo import get_demo_stocks
    stocks = get_demo_stocks()
    for s in stocks:
        s['_demo'] = True
    return stocks


# ── Index / Top50 / Anomaly / Sectors ───────────────────────────────

def get_index_data():
    cached = cache.get('index_data')
    # Only trust a non-empty cache. An empty list must never stick: otherwise a
    # single failed weekend fetch gets cached and blocks all fallbacks until restart.
    if cached:
        return cached

    names = ['上证指数', '深证成指', '创业板指', '科创50']
    codes = ['000001', '399001', '399006', '000688']
    result = []
    text = _fetch_sina('https://hq.sinajs.cn/list=sh000001,sz399001,sz399006,sh000688')
    if text:
        for i, line in enumerate(text.strip().split('\n')):
            m = re.search(r'"([^"]*)"', line)
            if m:
                parts = m.group(1).split(',')
                if len(parts) >= 6:
                    price = float(parts[3]) if parts[3] else 0
                    preclose = float(parts[2]) if parts[2] else 0
                    result.append({
                        'name': names[i] if i < len(names) else '',
                        'code': codes[i] if i < len(codes) else '',
                        'price': price,
                        'change_pct': round((price - preclose) / preclose * 100, 2)
                                      if preclose != 0 else 0,
                        'change': round(price - preclose, 2) if preclose != 0 else 0,
                        'volume': float(parts[8]) if len(parts) > 8 and parts[8] else 0,
                        'amount': float(parts[9]) if len(parts) > 9 and parts[9] else 0,
                    })

    # Fallback: fill missing/zero-price indices from latest DB snapshot (last close).
    if not result or any(r['price'] <= 0 for r in result):
        snap = None
        try:
            from ..db import get_db
            db = get_db()
            try:
                snap = db.execute(
                    "SELECT sh_close, sz_close, cy_close, kc_close FROM index_snapshot "
                    "WHERE sh_close > 0 ORDER BY date DESC LIMIT 1"
                ).fetchone()
            finally:
                db.close()
        except Exception:
            snap = None

        if snap:
            col_by_code = {'000001': 'sh_close', '399001': 'sz_close',
                           '399006': 'cy_close', '000688': 'kc_close'}
            if not result:
                # Sina returned nothing — rebuild all four from snapshot.
                for i, code in enumerate(codes):
                    px = snap[col_by_code[code]] or 0
                    result.append({'name': names[i], 'code': code, 'price': px,
                                   'change_pct': 0, 'change': 0, 'volume': 0, 'amount': 0})
            else:
                # Partial — patch only the zero-price entries.
                for r in result:
                    if r['price'] <= 0:
                        px = snap[col_by_code.get(r['code'], 'sh_close')] or 0
                        if px:
                            r['price'] = px
                            r['change_pct'] = 0
                            r['change'] = 0

    # Drop indices still at price=0 (e.g. kc_close absent in snapshot) so the
    # frontend never renders a 0.00 quote.
    result = [r for r in result if r.get('price', 0) > 0]

    if not result:
        from .demo import DEMO_INDICES
        return DEMO_INDICES  # last resort — do NOT cache, so the next call retries Sina

    cache.set('index_data', result)
    return result


def get_top50():
    stocks = get_stock_list()
    if not stocks:
        return []
    return sorted(stocks, key=lambda x: float(x.get('涨跌幅', 0)), reverse=True)[:50]


def get_anomaly_stocks():
    stocks = get_stock_list()
    anomalies = []
    for s in stocks:
        change = float(s.get('涨跌幅', 0))
        vol_r = float(s.get('量比', 0))
        if abs(change) > 2 or vol_r > 3:
            anomalies.append({**s, 'anomaly_type': '涨速' if change > 2 else ('急跌' if change < -2 else '放量')})
    return sorted(anomalies, key=lambda x: abs(float(x.get('涨跌幅', 0))), reverse=True)[:30]


def get_sector_data():
    cached = cache.get('sector_data')
    if cached is not None:
        return cached
    from .sectors import get_categorized_sectors
    result = get_categorized_sectors()
    if not result:
        from .demo import get_demo_sectors
        result = {'市场': get_demo_sectors()}
    cache.set('sector_data', result)
    return result


# ── K-line ──────────────────────────────────────────────────────────

def _fetch_kline_from_db(code, days):
    """Read K-line data from local DB."""
    try:
        from ..db import get_db
        db = get_db()
        try:
            rows = db.execute(
                "SELECT date, open, high, low, close, volume FROM stock_kline_daily "
                "WHERE stock_code=? ORDER BY date DESC LIMIT ?",
                (code, days)
            ).fetchall()
        finally:
            db.close()
        if rows:
            return [
                {'date': r['date'], 'open': r['open'], 'close': r['close'],
                 'high': r['high'], 'low': r['low'], 'volume': r['volume']}
                for r in reversed(rows)
            ]
    except Exception:
        pass
    return []


# ── Index (指数) OHLC ────────────────────────────────────────────────
# 指数代码与 Sina symbol 的映射。个股代码解析(_kline_prefix)会把 000001 当成
# 平安银行(sz000001), 指数必须显式映射, 否则 regime 判定会算错标的。
_INDEX_SINA_SYMBOL = {
    '000001': 'sh000001',   # 上证指数
    '399001': 'sz399001',   # 深证成指
    '399006': 'sz399006',   # 创业板指
    '000688': 'sh000688',   # 科创50
}


def _fetch_index_kline_sina(code, days):
    """Fetch index daily OHLC from Sina using the sh/sz index symbol."""
    symbol = _INDEX_SINA_SYMBOL.get(code)
    if not symbol:
        return []
    data = _fetch_sina_json(SINA_KLINE_URL, params={
        'symbol': symbol, 'scale': 240, 'datalen': days
    }, timeout=8)
    if not data:
        return []
    return [
        {'date': k.get('day', '')[:10], 'open': float(k.get('open', 0)),
         'close': float(k.get('close', 0)), 'high': float(k.get('high', 0)),
         'low': float(k.get('low', 0)), 'volume': float(k.get('volume', 0))}
        for k in data
    ]


def refresh_index_kline_daily(codes=None, days=20):
    """Upsert recent index OHLC into index_kline_daily (keeps live regime fresh).
    每日盘后调用: 抓最近 days 根指数OHLC 覆盖入库。DB-first 的 get_index_kline_data
    才不会读到陈旧数据。"""
    if codes is None:
        codes = list(_INDEX_SINA_SYMBOL.keys())
    from ..db import get_db
    db = get_db()
    n = 0
    try:
        for code in codes:
            rows = _fetch_index_kline_sina(code, days)
            for k in rows:
                if not k['date']:
                    continue
                db.execute(
                    "INSERT OR REPLACE INTO index_kline_daily "
                    "(index_code, date, open, high, low, close, volume) VALUES (?,?,?,?,?,?,?)",
                    (code, k['date'], k['open'], k['high'], k['low'], k['close'], k['volume']))
                n += 1
        db.commit()
    finally:
        db.close()
    # 缓存 TTL 仅 3s, 无需手动失效, 下次读自然刷新。
    return n


def _fetch_index_kline_from_db(code, days):
    """Read index K-line from index_kline_daily."""
    try:
        from ..db import get_db
        db = get_db()
        try:
            rows = db.execute(
                "SELECT date, open, high, low, close, volume FROM index_kline_daily "
                "WHERE index_code=? ORDER BY date DESC LIMIT ?",
                (code, days)
            ).fetchall()
        finally:
            db.close()
        if rows:
            return [
                {'date': r['date'], 'open': r['open'], 'close': r['close'],
                 'high': r['high'], 'low': r['low'], 'volume': r['volume']}
                for r in reversed(rows)
            ]
    except Exception:
        pass
    return []


def get_index_kline_data(index_code='000001', days=120):
    """Index daily OHLC (真指数, 非个股). DB first, Sina fallback.
    指数不做前复权(无除权)。用于 market_regime 的 ADX/均线判定。"""
    cache_key = f'idxkline_{index_code}_{days}'
    cached = cache.get(cache_key)
    if cached is not None:
        return cached
    result = _fetch_index_kline_from_db(index_code, days)
    if not result:
        result = _fetch_index_kline_sina(index_code, days)
    if result:
        cache.set(cache_key, result)
    return result


def get_kline_data(stock_code, days=60):
    cache_key = f'kline_{stock_code}_{days}'
    cached = cache.get(cache_key)
    if cached is not None:
        return cached

    # 1. DB first (instant if data imported)
    result = _fetch_kline_from_db(stock_code, days)
    if result:
        result = _apply_qfq(result, stock_code)   # 除权接缝前复权(只读)
        cache.set(cache_key, result)
        return result

    # 2. Sina API fallback (亦不复权,需同样处理)
    result = _fetch_kline_sina(stock_code, days)
    if not result:
        result = _fetch_kline_akshare(stock_code, days)
    if result:
        result = _apply_qfq(result, stock_code)
    else:
        from .demo import get_demo_kline
        result = get_demo_kline(stock_code, days)

    cache.set(cache_key, result)
    return result


def _kline_prefix(code):
    if code.startswith(('68', '6')):
        return 'sh'
    elif code.startswith(('0', '3', '2')):
        return 'sz'
    elif code.startswith(('92', '8', '9')):
        return 'bj'
    return 'sz'


def _fetch_kline_sina(code, days):
    prefix = _kline_prefix(code)
    data = _fetch_sina_json(SINA_KLINE_URL, params={
        'symbol': f'{prefix}{code}', 'scale': 240, 'datalen': days
    }, timeout=8)
    if data:
        return [
            {'date': k.get('day', '')[:10], 'open': float(k.get('open', 0)),
             'close': float(k.get('close', 0)), 'high': float(k.get('high', 0)),
             'low': float(k.get('low', 0)), 'volume': float(k.get('volume', 0))}
            for k in data
        ]
    return []


def _fetch_kline_akshare(code, days):
    try:
        import akshare as ak
        df = ak.stock_zh_a_hist(symbol=code, period='daily', adjust='qfq')
        if df is None or df.empty:
            return []
        df = df.tail(days)
        return [
            {'date': str(row.get('日期', ''))[:10],
             'open': _safe_float(row.get('开盘', 0)),
             'close': _safe_float(row.get('收盘', 0)),
             'high': _safe_float(row.get('最高', 0)),
             'low': _safe_float(row.get('最低', 0)),
             'volume': _safe_float(row.get('成交量', 0))}
            for _, row in df.iterrows()
        ]
    except:
        return []


def get_kline_analysis(stock_code, days=120):
    from .indicators import calc_sma, calc_macd, calc_kdj, calc_rsi
    from .patterns import detect_all

    klines = get_kline_data(stock_code, days)
    if not klines:
        return {'stock_code': stock_code, 'stock_name': '', 'klines': [], 'patterns': []}

    closes = [k['close'] for k in klines]
    highs = [k['high'] for k in klines]
    lows = [k['low'] for k in klines]

    ma5 = calc_sma(closes, 5)
    ma10 = calc_sma(closes, 10)
    ma20 = calc_sma(closes, 20)
    dif, dea, hist = calc_macd(closes)
    kdj_k, kdj_d, kdj_j = calc_kdj(highs, lows, closes)
    rsi = calc_rsi(closes, 14)

    for i, k in enumerate(klines):
        k['ma5'] = ma5[i] if i < len(ma5) else None
        k['ma10'] = ma10[i] if i < len(ma10) else None
        k['ma20'] = ma20[i] if i < len(ma20) else None
        k['macd_dif'] = dif[i] if i < len(dif) else None
        k['macd_dea'] = dea[i] if i < len(dea) else None
        k['macd_hist'] = hist[i] if i < len(hist) else None
        k['kdj_k'] = kdj_k[i] if i < len(kdj_k) else None
        k['kdj_d'] = kdj_d[i] if i < len(kdj_d) else None
        k['kdj_j'] = kdj_j[i] if i < len(kdj_j) else None
        k['rsi'] = rsi[i] if i < len(rsi) else None

    patterns = detect_all(klines)

    stock_name = ''
    try:
        stocks = get_stock_list()
        for s in stocks:
            if s.get('代码') == stock_code:
                stock_name = s.get('名称', '')
                break
    except:
        pass

    return {'stock_code': stock_code, 'stock_name': stock_name, 'klines': klines, 'patterns': patterns}


def get_holding_report(stock_code, cost=None, window=60, buy_date=None):
    """持仓体检报告。修复原 /analysis 接口无顶层价格字段导致的「白板」bug
    （前端取 d.price/d.change_pct 全为空 → 现价=成本=0%、风险默认 safe）。

    从 klines 自身推导真实现价/涨跌/回撤/波动/趋势，用 screener 同款权重做量化
    策略打分，并构建个股与四大指数在同一窗口内的累计收益率对比曲线（做法对齐
    量化看板 get_return_curve：各自以窗口首日为基归一化到累计收益%）。
    """
    import math
    from ..db import get_db

    need = max(window + 40, 120)
    # buy_date 较早时，需拉更多历史 K 线才能覆盖到那天（约 250 交易日/年 + 缓冲）
    if buy_date:
        try:
            days_ago = (datetime.now() - datetime.strptime(buy_date[:10], '%Y-%m-%d')).days
            if days_ago > 0:
                need = max(need, int(days_ago / 365 * 250) + 40)
        except (ValueError, TypeError):
            pass
    ana = get_kline_analysis(stock_code, need)
    klines = ana.get('klines') or []
    name = ana.get('stock_name') or stock_code
    if len(klines) < 20:
        return {'stock_code': stock_code, 'stock_name': name, 'ok': False,
                'error': '历史数据不足，无法体检'}

    closes = [k['close'] for k in klines]
    last, prev = klines[-1], klines[-2]

    # Real-time price + change: try fetch_quotes_for_codes first (bypasses K-line cache)
    realtime = fetch_quotes_for_codes([stock_code])
    rt_data = realtime.get(stock_code, {})
    price = rt_data.get('最新价', 0)
    change_pct = rt_data.get('涨跌幅', 0)

    # Fallback to K-line if realtime unavailable
    prev_close = prev['close']
    if not price or price <= 0:
        price = last['close']
        change_pct = round((price - prev_close) / prev_close * 100, 2) if prev_close else 0.0

    win_closes = closes[-window:] if len(closes) >= window else closes
    win_high = max(win_closes)
    drawdown_pct = round((price - win_high) / win_high * 100, 1) if win_high else 0.0

    rets = [(closes[i] - closes[i - 1]) / closes[i - 1]
            for i in range(1, len(closes)) if closes[i - 1]]
    win_rets = rets[-window:] if len(rets) >= window else rets
    vol_pct = 0.0
    if len(win_rets) >= 2:
        mean = sum(win_rets) / len(win_rets)
        var = sum((r - mean) ** 2 for r in win_rets) / (len(win_rets) - 1)
        vol_pct = round(math.sqrt(var) * math.sqrt(244) * 100, 1)

    ma5, ma20 = last.get('ma5'), last.get('ma20')
    rsi = last.get('rsi') if last.get('rsi') is not None else 50
    if ma5 and ma20:
        if ma5 > ma20 and price >= ma5:
            trend = '多头排列（短期均线在上，趋势向上）'
        elif ma5 < ma20 and price <= ma5:
            trend = '空头排列（短期均线在下，趋势向下）'
        else:
            trend = '均线纠缠（方向不明，震荡整理）'
    else:
        trend = '数据不足'

    # ── 量化策略打分（多维度评分，确保每只股票都有合理基础分）──
    score = 0
    score_items = {}
    reasons = []

    # 趋势强度打分（0-25分）
    if ma5 and ma20:
        if ma5 > ma20:
            gap_pct = (ma5 - ma20) / ma20 * 100
            if gap_pct >= 5:
                score += 25; score_items['趋势强劲'] = 25; reasons.append('均线多头排列且差距显著')
            elif gap_pct >= 2:
                score += 20; score_items['趋势向好'] = 20; reasons.append('均线多头排列')
            else:
                score += 15; score_items['趋势初现'] = 15; reasons.append('均线微多头')
        elif ma5 < ma20:
            gap_pct = (ma20 - ma5) / ma20 * 100
            if gap_pct <= 2:
                score += 10; score_items['趋势转换'] = 10; reasons.append('均线接近交叉')
            else:
                score += 5; score_items['趋势偏弱'] = 5; reasons.append('均线空头排列')
        else:
            score += 8; score_items['趋势震荡'] = 8; reasons.append('均线纠缠')

    # 动量指标打分（0-25分）
    dif, dea = last.get('macd_dif'), last.get('macd_dea')
    if dif is not None and dea is not None:
        if dif > dea and dif > 0:
            score += 25; score_items['动量强劲'] = 25; reasons.append('MACD金叉向上')
        elif dif > dea and dif <= 0:
            score += 18; score_items['动量修复'] = 18; reasons.append('MACD底部金叉')
        elif dif < dea and dif > 0:
            score += 12; score_items['动量回调'] = 12; reasons.append('MACD高位死叉')
        else:
            score += 5; score_items['动量偏弱'] = 5; reasons.append('MACD空头')

    # 成交量活跃度（0-20分）
    if len(klines) >= 6:
        avg_vol5 = sum(k['volume'] for k in klines[-6:-1]) / 5
        if avg_vol5 > 0:
            vol_ratio = last['volume'] / avg_vol5
            if vol_ratio > 2:
                score += 20; score_items['放量突破'] = 20; reasons.append('成交量剧增')
            elif vol_ratio > 1.5:
                score += 15; score_items['量能活跃'] = 15; reasons.append('成交量放大')
            elif vol_ratio > 0.8:
                score += 10; score_items['量能平稳'] = 10; reasons.append('成交量正常')
            else:
                score += 5; score_items['量能萎缩'] = 5; reasons.append('成交量缩量')

    # 超跌反弹潜力（0-15分）
    if rsi < 30:
        score += 15; score_items['超卖反弹'] = 15; reasons.append('RSI超卖')
    elif rsi < 40:
        score += 10; score_items['低位蓄势'] = 10; reasons.append('RSI偏低')
    elif rsi > 70:
        if rsi > 80:
            score += 3; score_items['超买风险'] = 3; reasons.append('RSI超买')
        else:
            score += 8; score_items['强势持续'] = 8; reasons.append('RSI强势')
    else:
        score += 12; score_items['指标中性'] = 12; reasons.append('RSI中性区')

    # 位置评估（0-15分）
    highs9 = [k['high'] for k in klines[-9:]]
    lows9 = [k['low'] for k in klines[-9:]]
    hi, lo = max(highs9), min(lows9)
    if hi != lo:
        pos_pct = (price - lo) / (hi - lo) * 100
        if pos_pct < 20:
            score += 15; score_items['低位机会'] = 15; reasons.append('价格近期低位')
        elif pos_pct < 40:
            score += 12; score_items['位置适中'] = 12; reasons.append('价格中低位')
        elif pos_pct < 60:
            score += 10; score_items['位置中性'] = 10; reasons.append('价格中部区间')
        elif pos_pct < 80:
            score += 8; score_items['位置偏高'] = 8; reasons.append('价格中高位')
        else:
            score += 5; score_items['高位压力'] = 5; reasons.append('价格近期高位')

    # ── 对比曲线：个股 vs 四大指数，窗口内累计收益% ──
    win_klines = klines[-window:] if len(klines) >= window else klines[:]
    if buy_date:
        picked = [k for k in klines if k['date'] >= buy_date]
        if len(picked) >= 2:
            win_klines = picked
    dates = [k['date'] for k in win_klines]
    start_date = dates[0]

    db = get_db()
    try:
        idx_rows = db.execute(
            "SELECT date, sh_close, sz_close, cy_close, kc_close FROM index_snapshot "
            "WHERE date >= ? ORDER BY date ASC", (start_date,)).fetchall()
    finally:
        db.close()
    idx_by_date = {r['date']: r for r in idx_rows}

    base_close = win_klines[0]['close']
    stock_cum = [round((k['close'] - base_close) / base_close * 100, 2) for k in win_klines]

    def idx_series(col):
        vals, base, last_v = [], None, 0.0
        for d in dates:
            row = idx_by_date.get(d)
            if row and row[col]:
                if base is None:
                    base = row[col]
                last_v = round((row[col] - base) / base * 100, 2) if base else 0.0
            vals.append(last_v)
        return vals

    pnl_pct = round((price - cost) / cost * 100, 2) if cost else None

    risk = 'safe'
    if vol_pct >= 45 or drawdown_pct <= -25 or rsi >= 80:
        risk = 'danger'
    elif vol_pct >= 30 or drawdown_pct <= -12 or rsi >= 72:
        risk = 'warn'

    return {
        'stock_code': stock_code, 'stock_name': name, 'ok': True,
        'price': round(price, 2), 'prev_close': round(prev_close, 2), 'change_pct': change_pct,
        'cost': cost, 'pnl_pct': pnl_pct,
        'drawdown_pct': drawdown_pct, 'volatility_pct': vol_pct,
        'ma5': round(ma5, 2) if ma5 else None, 'ma20': round(ma20, 2) if ma20 else None,
        'rsi': round(rsi, 1), 'trend': trend, 'risk': risk,
        'quant_score': score, 'score_items': score_items,
        'reasons': ', '.join(reasons) if reasons else '当前无明显多头信号',
        'window': window, 'start_date': start_date,
        'curve': {'dates': dates, 'stock': stock_cum,
                  'sh': idx_series('sh_close'), 'sz': idx_series('sz_close'),
                  'cy': idx_series('cy_close'), 'kc': idx_series('kc_close')},
    }


def get_price_at_date(stock_code, target_date):
    """查询股票在指定日期的收盘价，用于自动填充成本价。"""
    try:
        # 拉取足够长的历史（约1年），确保能覆盖到目标日期
        days_ago = (datetime.now() - datetime.strptime(target_date[:10], '%Y-%m-%d')).days
        need = max(300, int(days_ago / 365 * 250) + 60)
        klines = get_kline_data(stock_code, need)
        if not klines:
            return {'ok': False, 'error': '无法获取历史K线'}

        # 查找目标日期或之前最近的一个交易日
        target = target_date[:10]
        matched = None
        for k in reversed(klines):
            if k['date'] <= target:
                matched = k
                break

        if not matched:
            return {'ok': False, 'error': f'{target} 之前无交易数据'}

        return {
            'ok': True,
            'date': matched['date'],
            'close': round(matched['close'], 2)
        }
    except (ValueError, TypeError) as e:
        return {'ok': False, 'error': f'日期格式错误: {e}'}


def search_stocks(query):
    """股票名称/代码模糊搜索，返回匹配的前10条结果。"""
    try:
        stocks = get_stock_list()
        q = query.lower()
        matches = []
        for s in stocks:
            code = s.get('代码', '')
            name = s.get('名称', '')
            # 代码包含查询词 或 名称包含查询词（中英文都支持）
            if q in code.lower() or query in name or q in name.lower():
                matches.append({'code': code, 'name': name})
                if len(matches) >= 10:
                    break
        return {'ok': True, 'results': matches}
    except Exception as e:
        return {'ok': False, 'error': str(e)}


# ── Financial / News / Intraday ─────────────────────────────────────

def get_financial_data(stock_code):
    cached = cache.get(f'fin_{stock_code}')
    if cached is not None:
        return cached

    result = {}
    prefix = 'sh' if stock_code.startswith('6') else 'sz'
    text = _fetch_sina(f'https://hq.sinajs.cn/list={prefix}{stock_code}_i')
    if text:
        m = re.search(r'"([^"]*)"', text)
        if m:
            parts = m.group(1).split(',')
            try:
                pe_static = float(parts[2]) if len(parts) > 2 else 0
                pe_ttm = float(parts[14]) if len(parts) > 14 else 0
                if 0 < pe_ttm < 500:
                    result['pe'] = pe_ttm
                elif 0 < pe_static < 500:
                    result['pe'] = pe_static
            except (ValueError, IndexError):
                result['pe'] = 0
            result['pb'] = 0

            for part in parts:
                if '|' not in part or part[:4] not in ('2026', '2025'):
                    continue
                fin = part.split('|')
                if len(fin) < 9:
                    continue
                try:
                    result['roe'] = round(float(fin[6]) * 4, 2) if fin[6] else 0
                    result['debt_ratio'] = float(fin[8]) if fin[8] else 0
                    result['revenue_growth'] = float(fin[9]) if fin[9] else 0
                    result['profit_growth'] = float(fin[10]) if fin[10] else 0
                    break
                except (ValueError, IndexError):
                    pass

    if not result:
        try:
            import akshare as ak
            indicators = ak.stock_financial_analysis_indicator(symbol=stock_code)
            if not indicators.empty:
                latest = indicators.iloc[0]
                result = {
                    'pe': float(latest.get('市盈率', 0) or 0),
                    'pb': float(latest.get('市净率', 0) or 0),
                    'roe': float(latest.get('净资产收益率', 0) or 0),
                    'debt_ratio': float(latest.get('资产负债率', 0) or 0),
                    'revenue_growth': float(latest.get('营业收入增长率', 0) or 0),
                    'profit_growth': float(latest.get('净利润增长率', 0) or 0),
                }
        except:
            pass

    cache.set(f'fin_{stock_code}', result)
    return result


def get_intraday_data(stock_code):
    cached = cache.get(f'intraday_{stock_code}')
    if cached is not None:
        return cached

    result = []
    prefix = _kline_prefix(stock_code)
    data = _fetch_sina_json(SINA_KLINE_URL, params={
        'symbol': f'{prefix}{stock_code}', 'scale': 5, 'datalen': 60
    }, timeout=8)
    if data:
        result = [{'time': k.get('day', ''), 'price': float(k.get('close', 0))} for k in data]

    if not result:
        text = None
        try:
            resp = session.get(f'{TENCENT_QUOTE_URL}{prefix}{stock_code}', timeout=3)
            resp.encoding = 'gbk'
            if resp.status_code == 200:
                text = resp.text
        except:
            pass
        if text:
            parts = text.split('~')
            if len(parts) > 10:
                result = [{'time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 'price': float(parts[3])}]

    cache.set(f'intraday_{stock_code}', result)
    return result


def get_northbound_flow(stock_code: str, days: int = 5):
    """主力资金净流入（AKShare个股资金流向，北向偏好代理）。
    Returns {'net_5d': float (万元), 'bullish': bool} or None."""
    cache_key = f'northbound_{stock_code}'
    cached = cache.get(cache_key)
    if cached is not None:
        return cached
    try:
        import akshare as ak
        market = 'sh' if stock_code[:2] in ('60', '68', '11') else 'sz'
        df = ak.stock_individual_fund_flow(stock=stock_code, market=market)
        if df is None or df.empty:
            return None
        col = next((c for c in df.columns if '主力净流入' in c and '净额' in c), None)
        if col is None:
            return None
        net = df.tail(days)[col].astype(float).sum() / 10000
        result = {'net_5d': round(net, 2), 'bullish': net > 0}
        cache.set(cache_key, result)
        return result
    except Exception:
        return None


def get_market_news(count=10):
    # ... existing implementation
    return news


def get_risk_education(stock_code):
    """持仓风险教育端点：返回板块、波动率、最大回撤、RSI等风险识别指标。
    不包含交易建议，仅用于风险识别和金融教育。"""
    import math
    from ..db import get_db

    # 获取K线分析数据
    ana = get_kline_analysis(stock_code, days=120)
    klines = ana.get('klines') or []
    name = ana.get('stock_name') or stock_code

    if len(klines) < 20:
        return {
            'stock_code': stock_code,
            'stock_name': name,
            'ok': False,
            'error': '历史数据不足，无法分析'
        }

    closes = [k['close'] for k in klines]
    last = klines[-1]

    # 获取实时价格
    realtime = fetch_quotes_for_codes([stock_code])
    rt_data = realtime.get(stock_code, {})
    price = rt_data.get('最新价', 0)
    if not price or price <= 0:
        price = last['close']

    # 计算波动率（年化）
    rets = [(closes[i] - closes[i-1]) / closes[i-1]
            for i in range(1, len(closes)) if closes[i-1]]
    vol_pct = 0.0
    if len(rets) >= 20:
        mean = sum(rets) / len(rets)
        var = sum((r - mean) ** 2 for r in rets) / (len(rets) - 1)
        vol_pct = round(math.sqrt(var) * math.sqrt(244) * 100, 1)

    # 计算最大回撤
    highs = [k['high'] for k in klines[-60:]]
    max_high = max(highs) if highs else price
    max_drawdown_pct = round((price - max_high) / max_high * 100, 1) if max_high else 0.0

    # RSI指标
    rsi = last.get('rsi') if last.get('rsi') is not None else 50

    # 获取均线
    ma5 = last.get('ma5')
    ma20 = last.get('ma20')

    # 判断趋势
    trend = '数据不足'
    if ma5 and ma20:
        if ma5 > ma20 and price > ma5:
            trend = '多头排列（MA5>MA20>价格）'
        elif ma5 < ma20 and price < ma5:
            trend = '空头排列（价格<MA5<MA20）'
        elif price > ma5 > ma20:
            trend = '多头趋势'
        elif price < ma5 < ma20:
            trend = '空头趋势'
        else:
            trend = '震荡整理'

    # 计算量化评分（简化版，0-100分）
    quant_score = 50
    # RSI贡献（30-70为中性，偏离加减分）
    if 40 <= rsi <= 60:
        quant_score += 10
    elif 30 <= rsi < 40 or 60 < rsi <= 70:
        quant_score += 5
    elif rsi < 30:
        quant_score += 15  # 超卖加分
    else:  # rsi > 70
        quant_score -= 15  # 超买减分

    # 波动率贡献（波动越大分越低）
    if vol_pct < 25:
        quant_score += 10
    elif vol_pct < 35:
        quant_score += 5
    elif vol_pct > 50:
        quant_score -= 15

    # 回撤贡献（回撤越大分越低）
    if max_drawdown_pct > -5:
        quant_score += 15
    elif max_drawdown_pct > -10:
        quant_score += 10
    elif max_drawdown_pct < -25:
        quant_score -= 20
    elif max_drawdown_pct < -15:
        quant_score -= 10

    # 趋势贡献
    if '多头' in trend:
        quant_score += 10
    elif '空头' in trend:
        quant_score -= 10

    quant_score = max(0, min(100, quant_score))

    # 判断风险等级
    risk_level = 'safe'
    if vol_pct >= 45 or max_drawdown_pct <= -25 or rsi >= 80:
        risk_level = 'danger'
    elif vol_pct >= 30 or max_drawdown_pct <= -12 or rsi >= 72:
        risk_level = 'warn'

    # 识别板块
    sector = '未知板块'
    try:
        from .sectors import SECTOR_DEFS, stock_matches_sector
        for sec_name, cat, _etf in SECTOR_DEFS:
            if stock_matches_sector(name, sec_name):
                sector = sec_name
                break
    except:
        pass

    # 获取今日涨跌幅
    change_pct = rt_data.get('涨跌幅', 0.0)
    if not change_pct:
        if len(klines) >= 2:
            prev_close = klines[-2]['close']
            change_pct = round((price - prev_close) / prev_close * 100, 2) if prev_close else 0.0

    return {
        'ok': True,
        'stock_code': stock_code,
        'stock_name': name,
        'price': price,
        'change_pct': change_pct,
        'sector': sector,
        'volatility_pct': vol_pct,
        'drawdown_pct': max_drawdown_pct,
        'rsi': round(rsi, 0),
        'ma5': round(ma5, 2) if ma5 else None,
        'ma20': round(ma20, 2) if ma20 else None,
        'trend': trend,
        'quant_score': quant_score,
        'risk': risk_level,
    }


def get_market_news(count=10):
    cached = cache.get('market_news')
    if cached is not None:
        return cached

    news = []
    data = _fetch_sina_json(SINA_NEWS_URL, params={
        'pageid': 153, 'lid': 2512, 'k': '', 'num': count, 'page': 1
    }, timeout=8)
    if data and 'result' in data and 'data' in data['result']:
        for item in data['result']['data']:
            news.append({
                'title': item.get('title', ''),
                'intro': (item.get('intro', '') or '')[:200],
                'url': item.get('url', ''),
                'time': item.get('intime', ''),
                'source': item.get('source', '新浪财经'),
            })
    cache.set('market_news', news)
    return news


# ── Index history for return curve comparison ─────────────────────────

def save_daily_index_snapshot():
    """Save closing index values to DB. Call after market close."""
    today = datetime.now().strftime('%Y-%m-%d')
    from ..db import get_db
    # 刷新指数OHLC(保持 live regime 判定不读陈旧数据)。独立于下方快照的早退,
    # 即便今日快照已存在也要更新K线(盘中多次调用亦幂等: INSERT OR REPLACE)。
    try:
        refresh_index_kline_daily()
    except Exception:
        pass
    db = get_db()
    try:
        existing = db.execute("SELECT id FROM index_snapshot WHERE date=?", (today,)).fetchone()
        if existing:
            return

        data = get_index_data()
        sh = sz = cy = kc = 0.0
        for d in data:
            if d['code'] == '000001':
                sh = d['price']
            elif d['code'] == '399001':
                sz = d['price']
            elif d['code'] == '399006':
                cy = d['price']
            elif d['code'] == '000688':
                kc = d['price']

        if sh == 0 and sz == 0:
            return

        db.execute("INSERT OR REPLACE INTO index_snapshot (date, sh_close, sz_close, cy_close, kc_close) VALUES (?,?,?,?,?)",
                   (today, sh, sz, cy, kc))
        db.commit()
    finally:
        db.close()


def backfill_index_history():
    """Backfill index history from AKShare."""
    from ..db import get_db
    db = get_db()
    try:
        existing = db.execute("SELECT COUNT(*) as cnt FROM index_snapshot").fetchone()
    finally:
        db.close()
    if existing and existing['cnt'] > 0:
        return

    indices = [
        ('sh', 'sh000001'),
        ('sz', 'sz399001'),
        ('cy', 'sz399006'),
        ('kc', 'sh000688'),
    ]
    all_dates = set()
    index_data = {}

    try:
        import akshare as ak
        for key, symbol in indices:
            try:
                df = ak.stock_zh_index_daily(symbol=symbol)
                if df is not None and not df.empty:
                    index_data[key] = {str(row['date'])[:10]: float(row['close']) for _, row in df.iterrows()}
                    all_dates.update(index_data[key].keys())
            except:
                pass
    except:
        pass

    if not all_dates:
        return

    db = get_db()
    try:
        for date_str in sorted(all_dates):
            db.execute("INSERT OR REPLACE INTO index_snapshot (date, sh_close, sz_close, cy_close, kc_close) VALUES (?,?,?,?,?)",
                       (date_str,
                        index_data.get('sh', {}).get(date_str, 0),
                        index_data.get('sz', {}).get(date_str, 0),
                        index_data.get('cy', {}).get(date_str, 0),
                        index_data.get('kc', {}).get(date_str, 0)))
        db.commit()
    finally:
        db.close()


def get_return_curve():
    """Return daily cumulative returns for asset + 4 indices since account inception."""
    from ..db import get_db
    db = get_db()
    try:
        acc = db.execute("SELECT initial_capital, total_asset, created_at FROM account WHERE id=1").fetchone()
        if not acc:
            return {'dates': [], 'asset': [], 'sh': [], 'sz': [], 'cy': [], 'kc': []}

        initial = acc['initial_capital']
        live_total_asset = acc['total_asset']
        start_date = acc['created_at'][:10] if acc['created_at'] else datetime.now().strftime('%Y-%m-%d')

        snapshots = db.execute(
            "SELECT date, total_asset FROM asset_snapshot WHERE date >= ? ORDER BY date ASC",
            (start_date,)
        ).fetchall()

        index_rows = db.execute(
            "SELECT date, sh_close, sz_close, cy_close, kc_close FROM index_snapshot WHERE date >= ? ORDER BY date ASC",
            (start_date,)
        ).fetchall()
    finally:
        db.close()

    if not snapshots:
        return {'dates': [], 'asset': [], 'sh': [], 'sz': [], 'cy': [], 'kc': []}

    idx_by_date = {r['date']: r for r in index_rows}
    first_idx = index_rows[0] if index_rows else None

    today_str = datetime.now().strftime('%Y-%m-%d')

    # Fetch live index prices for today
    live_idx = {}
    try:
        # Use get_index_data which has fallback to DB
        idx_data = get_index_data()
        code_to_key = {'000001': 'sh', '399001': 'sz', '399006': 'cy', '000688': 'kc'}
        for item in idx_data:
            key = code_to_key.get(item.get('code', ''))
            if key and item.get('price', 0) > 0:
                live_idx[key] = item['price']
        if not live_idx:
            print(f'[CURVE] live_idx empty, idx_data={idx_data}')
    except Exception as e:
        import traceback
        print(f'[CURVE] live_idx error: {e}')
        traceback.print_exc()

    dates, asset_cum, sh_cum, sz_cum, cy_cum, kc_cum = [], [], [], [], [], []
    last_asset_ret = 0
    last_sh_ret = 0
    last_sz_ret = 0
    last_cy_ret = 0
    last_kc_ret = 0

    def calc_ret(cur, base):
        if base and base != 0:
            return round((cur - base) / base * 100, 2)
        return 0

    for s in snapshots:
        date_str = s['date']
        dates.append(date_str)

        # Use live total_asset for today's data point
        asset_val = live_total_asset if date_str == today_str else s['total_asset']
        asset_ret = round((asset_val - initial) / initial * 100, 2) if initial else 0
        last_asset_ret = asset_ret
        asset_cum.append(asset_ret)

        # Index cumulative returns — use live prices for today
        is_today = (date_str == today_str)
        idx = idx_by_date.get(date_str)
        if first_idx:
            if is_today and live_idx:
                sh_cum.append(calc_ret(live_idx.get('sh', 0) or 0, first_idx['sh_close']))
                sz_cum.append(calc_ret(live_idx.get('sz', 0) or 0, first_idx['sz_close']))
                cy_cum.append(calc_ret(live_idx.get('cy', 0) or 0, first_idx['cy_close']))
                kc_cum.append(calc_ret(live_idx.get('kc', 0) or 0, first_idx['kc_close']))
            elif idx:
                sh_cum.append(calc_ret(idx['sh_close'] or 0, first_idx['sh_close']))
                sz_cum.append(calc_ret(idx['sz_close'] or 0, first_idx['sz_close']))
                cy_cum.append(calc_ret(idx['cy_close'] or 0, first_idx['cy_close']))
                kc_cum.append(calc_ret(idx['kc_close'] or 0, first_idx['kc_close']))
            else:
                sh_cum.append(last_sh_ret)
                sz_cum.append(last_sz_ret)
                cy_cum.append(last_cy_ret)
                kc_cum.append(last_kc_ret)
        else:
            sh_cum.append(last_sh_ret)
            sz_cum.append(last_sz_ret)
            cy_cum.append(last_cy_ret)
            kc_cum.append(last_kc_ret)

        last_sh_ret, last_sz_ret = sh_cum[-1], sz_cum[-1]
        last_cy_ret, last_kc_ret = cy_cum[-1], kc_cum[-1]

    return {
        'dates': dates,
        'asset': asset_cum,
        'sh': sh_cum,
        'sz': sz_cum,
        'cy': cy_cum,
        'kc': kc_cum,
    }
