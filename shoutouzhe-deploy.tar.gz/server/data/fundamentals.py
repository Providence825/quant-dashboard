import warnings
from datetime import date
import pandas as pd
import akshare as ak

COL_MAP = {
    '日期': 'report_date',
    '净资产收益率(%)': 'roe',
    '销售毛利率(%)': 'gross_margin',
    '销售净利率(%)': 'net_margin',
    '主营业务收入增长率(%)': 'revenue_yoy',
    '净利润增长率(%)': 'profit_yoy',
    '资产负债率(%)': 'debt_ratio',
    '流动比率': 'current_ratio',
    '速动比率': 'quick_ratio',
    '总资产利润率(%)': 'roa',
    '总资产(元)': 'total_assets',
}


def _calc_ann_date(report_date: str) -> str:
    """Conservative disclosure deadline by regulatory rules (no lookahead bias)."""
    dt = date.fromisoformat(report_date)
    m, y = dt.month, dt.year
    if m == 3:   return f"{y}-04-30"
    elif m == 6: return f"{y}-08-31"
    elif m == 9: return f"{y}-10-31"
    else:        return f"{y+1}-04-30"  # 年报


def _strip_market(code: str) -> str:
    return code[2:] if code[:2] in ('SH', 'SZ') else code


def fetch_financial_data(code: str, start_year: str = '2023') -> pd.DataFrame:
    six = _strip_market(code)
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        raw = ak.stock_financial_analysis_indicator(symbol=six, start_year=start_year)
    wanted = {k: v for k, v in COL_MAP.items() if k in raw.columns}
    df = raw[list(wanted.keys())].rename(columns=wanted).copy()
    df['report_date'] = pd.to_datetime(df['report_date']).dt.strftime('%Y-%m-%d')
    for col in df.columns:
        if col != 'report_date':
            df[col] = pd.to_numeric(df[col], errors='coerce')
    return df


def save_financial_data(conn, code: str, df: pd.DataFrame) -> int:
    if df.empty:
        return 0
    rows = [{'stock_code': code, 'ann_date': _calc_ann_date(r['report_date']), **r}
            for r in df.to_dict('records')]
    conn.executemany(
        '''INSERT OR REPLACE INTO stock_fundamentals
           (stock_code, report_date, ann_date, roe, gross_margin, net_margin,
            revenue_yoy, profit_yoy, debt_ratio, current_ratio, quick_ratio,
            roa, total_assets)
           VALUES (:stock_code, :report_date, :ann_date, :roe, :gross_margin, :net_margin,
                   :revenue_yoy, :profit_yoy, :debt_ratio, :current_ratio, :quick_ratio,
                   :roa, :total_assets)''',
        rows
    )
    conn.commit()
    return len(rows)


def fetch_and_save(conn, code: str, start_year: str = '2023') -> int:
    df = fetch_financial_data(code, start_year)
    return save_financial_data(conn, code, df)


def get_latest_fundamentals(conn, code: str, as_of: str = None) -> dict | None:
    """Return the most recent fundamental row for a stock, optionally point-in-time."""
    if as_of:
        row = conn.execute(
            'SELECT * FROM stock_fundamentals WHERE stock_code=? AND ann_date<=? '
            'ORDER BY report_date DESC LIMIT 1',
            (code, as_of)
        ).fetchone()
    else:
        row = conn.execute(
            'SELECT * FROM stock_fundamentals WHERE stock_code=? ORDER BY report_date DESC LIMIT 1',
            (code,)
        ).fetchone()
    return dict(row) if row else None
