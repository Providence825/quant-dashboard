"""
Sentiment data fetcher — collects market sentiment from Xueqiu and web sources.
Uses Xueqiu cookies (if configured) for authenticated access to hot topics,
plus web search for broader sentiment indicators.
"""

import requests
import json
import os
import re
import time
from datetime import datetime
from ..db import get_db


def _load_xueqiu_cookies():
    """Load Xueqiu cookies from agent-reach config or local file."""
    # 1. Try agent-reach config
    try:
        import yaml
        config_path = os.path.expanduser('~/.agent-reach/config.yaml')
        if os.path.exists(config_path):
            with open(config_path, 'r') as f:
                config = yaml.safe_load(f)
            cookie_str = config.get('xueqiu_cookie', '')
            if cookie_str:
                return cookie_str
    except:
        pass

    # 2. Try local json file
    try:
        local_file = os.path.join(os.path.dirname(__file__), '..', '..', 'xueqiu_cookies.json')
        if os.path.exists(local_file):
            with open(local_file, 'r') as f:
                return json.load(f)
    except:
        pass

    return ''


def fetch_xueqiu_hot_timeline():
    """
    Fetch Xueqiu hot timeline and trending topics.
    Uses the same endpoints as agent-reach xueqiu channel.
    Returns list of text snippets for sentiment analysis.
    """
    cookie_str = _load_xueqiu_cookies()
    texts = []

    headers = {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'application/json, text/plain, */*',
        'Referer': 'https://xueqiu.com/',
    }
    if cookie_str:
        headers['Cookie'] = cookie_str

    try:
        sess = requests.Session()
        sess.headers.update(headers)

        # Visit homepage to set acw_tc anti-DDoS cookie
        sess.get('https://xueqiu.com/', timeout=10)
        time.sleep(0.5)

        # 1. Hot timeline (v4 public timeline)
        resp = sess.get(
            'https://xueqiu.com/v4/statuses/public_timeline_by_category.json'
            '?since_id=-1&max_id=-1&count=20&category=-1',
            timeout=15
        )
        if resp.status_code == 200:
            data = resp.json()
            items = data.get('list', [])
            for item in (items or [])[:20]:
                try:
                    post = json.loads(item['data']) if isinstance(item.get('data'), str) else {}
                except (json.JSONDecodeError, KeyError):
                    post = {}

                title = post.get('title', '') or ''
                text = post.get('text', '') or post.get('description', '') or ''
                # Strip HTML
                text = re.sub(r'<[^>]+>', '', text)
                full_text = f'{title} {text}'.strip()

                if full_text and len(full_text) > 10:
                    texts.append(full_text[:300])

                like_count = post.get('like_count', 0)
                reply_count = post.get('reply_count', 0)
                if like_count > 50:
                    texts.append(f'高赞热帖 点赞:{like_count} 回复:{reply_count} {title[:60]}')

        # 2. Hot stocks (人气榜)
        resp2 = sess.get(
            'https://stock.xueqiu.com/v5/stock/hot_stock/list.json?size=15&type=10',
            timeout=10
        )
        if resp2.status_code == 200:
            data2 = resp2.json()
            items = data2.get('data', {}).get('items', [])
            hot_names = []
            for item in (items or [])[:15]:
                name = item.get('name', '')
                pct = item.get('percent') or 0
                if name:
                    hot_names.append(f'{name}({pct:+.1f}%)')
            if hot_names:
                texts.append('人气榜: ' + ' '.join(hot_names))

        # 3. Search for sentiment-related topics
        for query in ['市场情绪', '恐慌', '贪婪']:
            try:
                resp3 = sess.get(
                    f'https://xueqiu.com/statuses/search.json?count=5&comment=0&symbol=&source=all&q={query}',
                    timeout=10
                )
                if resp3.status_code == 200:
                    data3 = resp3.json()
                    items3 = data3.get('list', [])
                    for item in (items3 or [])[:5]:
                        title = (item.get('title', '') or item.get('text', ''))[:150]
                        if title:
                            texts.append(f'搜索"{query}": {title}')
            except:
                pass

    except Exception as e:
        print(f'[Sentiment] Xueqiu fetch failed: {e}')

    return texts


def fetch_market_breadth_sentiment():
    """
    Derive sentiment from market technical indicators:
    - Limit-up vs limit-down ratio
    - Market breadth (up/down ratio)
    - Volume change vs 5-day average
    Returns text descriptions for sentiment analysis.
    """
    texts = []

    try:
        from ..data import fetcher

        stocks = fetcher.get_stock_list()
        if not stocks:
            return texts

        up_count = 0
        down_count = 0
        limit_up = 0
        limit_down = 0

        for s in stocks:
            change = float(s.get('涨跌幅', 0))
            if change > 0:
                up_count += 1
            elif change < 0:
                down_count += 1
            if change >= 9.8:
                limit_up += 1
            elif change <= -9.8:
                limit_down += 1

        total = max(up_count + down_count, 1)
        breadth = up_count / total * 100

        # Generate sentiment text from market data
        if breadth > 70:
            texts.append(f'市场普涨 涨跌比{up_count}:{down_count} 涨停{limit_up}家 情绪高涨')
        elif breadth > 55:
            texts.append(f'市场偏强 涨跌比{up_count}:{down_count} 涨停{limit_up}家')
        elif breadth > 45:
            texts.append(f'市场分化 涨跌比{up_count}:{down_count} 涨停{limit_up}家 跌停{limit_down}家')
        elif breadth > 30:
            texts.append(f'市场偏弱 涨跌比{up_count}:{down_count} 跌停{limit_down}家')
        else:
            texts.append(f'市场普跌 涨跌比{up_count}:{down_count} 跌停{limit_down}家 情绪低迷')

        if limit_up >= 100:
            texts.append(f'百股涨停 市场热度极高 游资活跃')
        if limit_down >= 50:
            texts.append(f'跌停潮{limit_down}家 恐慌情绪蔓延')
        if limit_up >= 50 and limit_down >= 20:
            texts.append(f'涨停{limit_up} 跌停{limit_down} 极端分化')

        # Index data
        indices = fetcher.get_index_data()
        for idx in (indices or []):
            change = idx.get('change_pct', 0)
            name = idx.get('name', '')
            if name in ('上证指数', '创业板指'):
                if change > 2:
                    texts.append(f'{name}{change:+.1f}% 大幅上涨')
                elif change > 1:
                    texts.append(f'{name}{change:+.1f}% 温和上涨')
                elif change < -2:
                    texts.append(f'{name}{change:+.1f}% 大幅下跌')
                elif change < -1:
                    texts.append(f'{name}{change:+.1f}% 温和下跌')

    except Exception as e:
        print(f'[Sentiment] Breadth fetch failed: {e}')

    return texts


def fetch_all_sentiment_sources():
    """
    Fetch from all available sources and return combined text list.
    """
    all_texts = []

    # 1. Xueqiu hot timeline
    print('[Sentiment] Fetching Xueqiu hot timeline...')
    xq_texts = fetch_xueqiu_hot_timeline()
    all_texts.extend(xq_texts)
    print(f'[Sentiment] Xueqiu: {len(xq_texts)} snippets')

    # 2. Market breadth
    print('[Sentiment] Fetching market breadth...')
    breadth_texts = fetch_market_breadth_sentiment()
    all_texts.extend(breadth_texts)
    print(f'[Sentiment] Breadth: {len(breadth_texts)} snippets')

    # 3. DB sentiment history (yesterday's data for continuity)
    try:
        db = get_db()
        try:
            yesterday = db.execute(
                "SELECT sentiment_score, phase FROM daily_sentiment ORDER BY date DESC LIMIT 1"
            ).fetchone()
        finally:
            db.close()
        if yesterday:
            y = dict(yesterday)
            all_texts.append(f'昨日情绪分{y["sentiment_score"]} 昨日阶段{y["phase"]}')
    except:
        pass

    # Deduplicate
    seen = set()
    unique = []
    for t in all_texts:
        if t not in seen:
            seen.add(t)
            unique.append(t)

    return unique
