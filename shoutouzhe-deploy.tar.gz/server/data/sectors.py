"""Sector data via ETF proxy quotes. Categorized for grouped treemap display."""

import threading
import time

# Sector → ETF mapping with categories
# Each sector has: name, category, etf_code (used to fetch real-time performance)
SECTOR_DEFS = [
    # ===== 科技 =====
    ('半导体',       '科技', 'sh512480'),
    ('芯片',         '科技', 'sz159995'),
    ('5G通信',       '科技', 'sh515050'),
    ('人工智能',     '科技', 'sz159819'),
    ('消费电子',     '科技', 'sz159732'),
    ('软件/信创',    '科技', 'sz159852'),
    ('大数据',       '科技', 'sh516000'),
    ('云计算',       '科技', 'sh516510'),
    ('机器人',       '科技', 'sh159770'),
    ('军工电子',     '科技', 'sh512660'),

    # ===== 新能源/制造 =====
    ('新能源车',     '新能源', 'sh515030'),
    ('光伏',         '新能源', 'sh515790'),
    ('锂电池',       '新能源', 'sz159840'),
    ('储能',         '新能源', 'sh516090'),
    ('风电',         '新能源', 'sh516350'),
    ('电力设备',     '新能源', 'sz159611'),
    ('汽车整车',     '制造',   'sh516110'),
    ('工业母机',     '制造',   'sz159663'),
    ('航天航空',     '制造',   'sh512810'),
    ('机械设备',     '制造',   'sh516960'),

    # ===== 大消费 =====
    ('白酒',         '消费', 'sh512690'),
    ('食品饮料',     '消费', 'sh515170'),
    ('家电',         '消费', 'sz159996'),
    ('农业/养殖',    '消费', 'sz159825'),
    ('纺织服装',     '消费', 'sh516130'),
    ('旅游/免税',    '消费', 'sh516590'),
    ('传媒/游戏',    '消费', 'sz159869'),
    ('医药生物',     '消费', 'sh512010'),
    ('医疗器械',     '消费', 'sz159883'),
    ('中药',         '消费', 'sh516500'),

    # ===== 金融/周期 =====
    ('银行',         '金融周期', 'sh512800'),
    ('券商',         '金融周期', 'sh512880'),
    ('保险',         '金融周期', 'sh512070'),
    ('房地产',       '金融周期', 'sh512200'),
    ('基建',         '金融周期', 'sh516970'),
    ('建材',         '金融周期', 'sz159745'),
    ('煤炭',         '金融周期', 'sh515220'),
    ('钢铁',         '金融周期', 'sh515210'),
    ('有色金属',     '金融周期', 'sz159871'),
    ('化工',         '金融周期', 'sh516020'),
    ('石油石化',     '金融周期', 'sz159930'),
    ('电力/公用',    '金融周期', 'sz159611'),
    ('交通运输',     '金融周期', 'sh516530'),
]


def get_categorized_sectors():
    """Fetch sector performance via ETF quotes, grouped by category."""
    # Collect all ETF codes
    etf_codes = [s[2] for s in SECTOR_DEFS]

    # Fetch quotes via Sina batch API
    prices = {}
    try:
        import requests
        url = 'https://hq.sinajs.cn/list=' + ','.join(etf_codes)
        resp = requests.get(url, headers={
            'User-Agent': 'Mozilla/5.0', 'Referer': 'https://finance.sina.com.cn'
        }, timeout=8)
        resp.encoding = 'gbk'
        if resp.status_code == 200:
            import re
            lines = resp.text.strip().split('\n')
            for line in lines:
                m = re.search(r'hq_str_(\w+)="([^"]*)"', line)
                if m:
                    code = m.group(1)
                    parts = m.group(2).split(',')
                    if len(parts) >= 4 and parts[2] and parts[3]:
                        try:
                            prev_close = float(parts[2])
                            current = float(parts[3])
                            if prev_close > 0:
                                prices[code] = round((current - prev_close) / prev_close * 100, 2)
                        except (ValueError, ZeroDivisionError):
                            pass
    except:
        pass

    # If ETF quotes failed, use stock-list-derived data
    if not prices:
        prices = _derive_from_stocks()

    # Build categorized result
    categories = {}
    for name, cat, etf in SECTOR_DEFS:
        chg = prices.get(etf, 0)
        if cat not in categories:
            categories[cat] = []
        categories[cat].append({'name': name, 'change_pct': chg, 'etf': etf})

    return categories


def _derive_from_stocks():
    """Derive sector performance from stock list when ETF API fails."""
    prices = {}
    try:
        from ..data import fetcher
        stocks = fetcher.get_stock_list()
        if not stocks:
            return prices

        # Keyword matching: sector name → aggregate stock changes
        sector_stocks = {}
        keyword_map = {
            'sh512480': ['半导体', '芯片'],
            'sz159995': ['芯片', '集成电路'],
            'sh515050': ['通信', '5G'],
            'sz159819': ['人工智能', 'AI', '智能'],
            'sz159732': ['电子'],
            'sz159852': ['软件', '信创', '信息'],
            'sh516000': ['数据'],
            'sh516510': ['云', '云计算'],
            'sh159770': ['机器人'],
            'sh512660': ['军工'],
            'sh515030': ['新能源'],
            'sh515790': ['光伏'],
            'sz159840': ['锂', '电池'],
            'sh516090': ['储能'],
            'sh516350': ['风电'],
            'sz159611': ['电力'],
            'sh516110': ['汽车'],
            'sz159663': ['机床'],
            'sh512810': ['航空'],
            'sh516960': ['机械'],
            'sh512690': ['白酒', '酒'],
            'sh515170': ['食品', '饮料'],
            'sz159996': ['家电'],
            'sz159825': ['农业', '养殖', '牧原'],
            'sh516130': ['纺织', '服装'],
            'sh516590': ['旅游', '免税'],
            'sz159869': ['传媒', '游戏'],
            'sh512010': ['医药', '医疗', '药'],
            'sz159883': ['器械', '医疗'],
            'sh516500': ['中药'],
            'sh512800': ['银行'],
            'sh512880': ['证券', '券商'],
            'sh512070': ['保险'],
            'sh512200': ['地产', '房地产'],
            'sh516970': ['基建', '建筑'],
            'sz159745': ['建材', '水泥'],
            'sz159871': ['煤炭', '有色', '矿', '金属'],
            'sh515210': ['钢铁'],
            'sh516020': ['化工', '化学'],
            'sz159930': ['石油', '石化'],
            'sh516530': ['交通', '运输', '物流'],
        }

        for etf, keywords in keyword_map.items():
            matched = []
            for s in stocks:
                name = s.get('名称', '')
                if any(kw in name for kw in keywords):
                    matched.append(float(s.get('涨跌幅', 0)))
            if matched:
                prices[etf] = round(sum(matched) / len(matched), 2)
    except:
        pass
    return prices


# ── Sector strength ranking (板块强度排名) ────────────────────────────

_sector_strength_cache = None
_sector_strength_ts = 0.0
_SECTOR_STRENGTH_TTL = 30


def compute_sector_strength():
    """
    Rank all sectors by composite strength: avg change + breadth + leader quality.

    Returns list of [{name, category, strength_score, avg_change, up_count, total_count, leader}]
    sorted by strength_score descending.
    """
    global _sector_strength_cache, _sector_strength_ts
    now = time.time()
    if _sector_strength_cache and (now - _sector_strength_ts) < _SECTOR_STRENGTH_TTL:
        return _sector_strength_cache

    from ..data import fetcher
    stocks = fetcher.get_stock_list()
    if not stocks:
        return []

    sector_data = {}
    for name, cat, _etf in SECTOR_DEFS:
        sector_data[name] = {'category': cat, 'changes': [], 'names': [], 'codes': []}

    for s in stocks:
        stock_name = s.get('名称', '')
        code = s.get('代码', '')
        change = float(s.get('涨跌幅', 0))

        for sec_name in sector_data:
            sec_short = sec_name.replace('/', '').replace(' ', '')
            if len(sec_short) >= 2 and sec_short[:2] in stock_name:
                sector_data[sec_name]['changes'].append(change)
                sector_data[sec_name]['names'].append(stock_name)
                sector_data[sec_name]['codes'].append(code)
                break

    results = []
    for sec_name, data in sector_data.items():
        changes = data['changes']
        if not changes:
            continue

        avg_change = round(sum(changes) / len(changes), 2)
        up_count = sum(1 for c in changes if c > 0)
        total = len(changes)
        up_ratio = up_count / total * 100

        best_idx = max(range(len(changes)), key=lambda i: changes[i])
        leader = data['names'][best_idx] if best_idx < len(data['names']) else ''
        leader_code = data['codes'][best_idx] if best_idx < len(data['codes']) else ''
        leader_change = changes[best_idx]

        score = round(avg_change * 3 + up_ratio * 0.3 + leader_change * 1.5, 1)

        results.append({
            'name': sec_name,
            'category': data['category'],
            'strength_score': score,
            'avg_change': avg_change,
            'up_count': up_count,
            'total_count': total,
            'up_ratio': round(up_ratio, 1),
            'leader': leader,
            'leader_code': leader_code,
            'leader_change': leader_change,
        })

    results.sort(key=lambda x: x['strength_score'], reverse=True)
    _sector_strength_cache = results
    _sector_strength_ts = now
    return results


def _sector_short(sec_name):
    return sec_name.replace('/', '').replace(' ', '')


def stock_matches_sector(stock_name, sec_name):
    """Same name-match rule used across sector ranking: sector short-name first-2-chars in stock name."""
    short = _sector_short(sec_name)
    return len(short) >= 2 and short[:2] in stock_name


def get_sector_momentum(sec_names, top=8):
    """当日动量排名:给定板块名列表,返回板块内 A 股按当日涨跌+量比排序。

    不过滤方向(隔夜美股跌时整板块可能全绿,仍要能出榜)。
    返回 {sector: [{stock_code, stock_name, price, change_pct, vol_ratio, turnover}]}。
    """
    from ..data import fetcher
    stocks = fetcher.get_stock_list()
    out = {}
    if not stocks:
        return {name: [] for name in sec_names}

    for sec_name in sec_names:
        rows = []
        for s in stocks:
            name = s.get('名称', '')
            if not stock_matches_sector(name, sec_name):
                continue
            rows.append({
                'stock_code': s.get('代码', ''),
                'stock_name': name,
                'price': float(s.get('最新价', 0)),
                'change_pct': float(s.get('涨跌幅', 0)),
                'vol_ratio': float(s.get('量比', 0)),
                'turnover': float(s.get('换手率', 0)),
            })
        rows.sort(key=lambda x: x['change_pct'] * 2 + x['vol_ratio'] * 1.5, reverse=True)
        out[sec_name] = rows[:top]
    return out


def get_top_sector_stocks(n=3):
    """
    Get best stocks in top N sectors (最强前排).

    Returns list of {stock_code, stock_name, price, change_pct, score, sector, sector_rank}
    """
    sectors = compute_sector_strength()
    if not sectors:
        return []

    top_sectors = [(s['name'], s['category']) for s in sectors[:n]]

    from ..data import fetcher
    stocks = fetcher.get_stock_list()
    if not stocks:
        return []

    results = []
    for rank, (sec_name, cat) in enumerate(top_sectors):
        sec_short = sec_name.replace('/', '').replace(' ', '')
        sector_stocks = []
        for s in stocks:
            name = s.get('名称', '')
            if len(sec_short) >= 2 and sec_short[:2] in name:
                change = float(s.get('涨跌幅', 0))
                vol_ratio = float(s.get('量比', 0))
                turnover = float(s.get('换手率', 0))
                if change > 0:
                    sector_stocks.append({
                        'stock_code': s.get('代码', ''),
                        'stock_name': name,
                        'price': float(s.get('最新价', 0)),
                        'change_pct': change,
                        'vol_ratio': vol_ratio,
                        'turnover': turnover,
                    })

        sector_stocks.sort(key=lambda x: x['change_pct'] * 2 + x['vol_ratio'] * 1.5, reverse=True)
        for stock in sector_stocks[:5]:
            results.append({
                **stock,
                'sector': sec_name,
                'category': cat,
                'sector_rank': rank + 1,
                'score': round(stock['change_pct'] * 5 + stock['vol_ratio'] * 8, 1),
            })

    results.sort(key=lambda x: x['score'], reverse=True)
    return results[:20]
