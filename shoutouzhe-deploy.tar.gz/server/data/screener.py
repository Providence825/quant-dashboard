from ..data import fetcher
from ..db import get_db
from ..data.fundamentals import get_latest_fundamentals
from datetime import datetime

def run_screener(conditions=None):
    conditions = conditions or {}
    l1 = conditions.get('level1', {})
    l2 = conditions.get('level2', {})
    l3 = conditions.get('level3', {})
    today_str = datetime.now().strftime('%Y-%m-%d')

    stocks = fetcher.get_stock_list()  # DB-first with live price overlay
    if isinstance(stocks, dict) and 'error' in stocks:
        return []

    fund_db = get_db()
    results = []
    for s in stocks:
        code = s['代码']
        name = s['名称']
        price = float(s['最新价'])
        change_pct = float(s.get('涨跌幅', 0))
        volume_ratio = float(s.get('量比', 0))
        turnover = float(s.get('换手率', 0))

        reasons = []
        score = 0
        score_items = {}
        level1_checks = []
        level2_checks = []
        level3_checks = []

        max_price = l1.get('max_price', 100)
        exclude_st = l1.get('exclude_st', True)
        check_revenue = l1.get('revenue_growth_positive', False)

        # === Level 1: 基础筛选 ===
        st_pass = True
        if exclude_st:
            st_pass = not ('ST' in name or '退' in name)
        level1_checks.append({
            'name': '非ST/退市', 'passed': st_pass,
            'detail': '通过' if st_pass else f'含ST或退市标识'
        })
        if not st_pass:
            continue

        price_pass = price <= max_price
        level1_checks.append({
            'name': f'股价≤{max_price}元', 'passed': price_pass,
            'detail': f'当前 ¥{price:.2f}' if price_pass else f'¥{price:.2f} 超过上限'
        })
        if not price_pass:
            continue

        if check_revenue:
            fin = fetcher.get_financial_data(code)
            rev_ok = fin and fin.get('revenue_growth', 0) >= 0
            level1_checks.append({
                'name': '营收正增长', 'passed': rev_ok,
                'detail': f'{fin.get("revenue_growth", 0):.1f}%' if fin else '数据不可用'
            })
            if not rev_ok:
                continue
        else:
            level1_checks.append({
                'name': '营收正增长', 'passed': True, 'detail': '未启用（跳过）'
            })

        # === Level 2: 财务筛选 ===
        has_level2 = any([l2.get('pe_min'), l2.get('pb_min'), l2.get('roe_min'),
                          l2.get('debt_max'), l2.get('cashflow_positive')])

        if has_level2:
            fin = fetcher.get_financial_data(code)
            fin_available = bool(fin)
            level2_checks.append({
                'name': '财务数据可用', 'passed': fin_available,
                'detail': '已获取' if fin_available else 'AKShare不可用，跳过财务筛选'
            })

            if not fin_available:
                # No financial data — skip level2 checks but don't exclude
                pass
            else:
                pe = fin.get('pe', 0)
                pe_pass = 10 <= pe <= 60
                level2_checks.append({
                    'name': 'PE 10-60', 'passed': pe_pass,
                    'detail': f'PE={pe:.1f}' if pe else '无数据'
                })

                pb = fin.get('pb', 0)
                pb_pass = pb <= 0 or (1 <= pb <= 8)  # Skip PB check if unavailable
                level2_checks.append({
                    'name': 'PB 1-8', 'passed': pb_pass,
                    'detail': f'PB={pb:.1f}' if pb > 0 else '数据不可用（跳过）'
                })

                roe = fin.get('roe', 0)
                roe_pass = roe >= 8
                level2_checks.append({
                    'name': 'ROE≥8%', 'passed': roe_pass,
                    'detail': f'ROE={roe:.1f}%' if roe else '无数据'
                })

                debt = fin.get('debt_ratio', 100)
                debt_pass = debt <= 70
                level2_checks.append({
                    'name': '负债率≤70%', 'passed': debt_pass,
                    'detail': f'{debt:.1f}%' if debt else '无数据'
                })

                fin_parts = [f'PE={pe:.1f}'] if pe else []
                if pb > 0:
                    fin_parts.append(f'PB={pb:.1f}')
                if roe:
                    fin_parts.append(f'ROE={roe:.1f}%')
                reasons.append('/'.join(fin_parts) if fin_parts else '财务数据部分可用')
        else:
            level2_checks.append({
                'name': '财务筛选', 'passed': True,
                'detail': '未启用（跳过）'
            })

        # DB-sourced fundamentals: profit_yoy / revenue_yoy (point-in-time)
        db_fund = get_latest_fundamentals(fund_db, code, as_of=today_str)
        if db_fund:
            pyoy = db_fund.get('profit_yoy')
            ryoy = db_fund.get('revenue_yoy')
            if pyoy is not None:
                pyoy_pass = pyoy > 0
                level2_checks.append({
                    'name': '净利润同比', 'passed': pyoy_pass,
                    'detail': f'{pyoy:+.1f}%' if pyoy_pass else f'{pyoy:+.1f}% (负增长)'
                })
                if pyoy_pass:
                    score += 10
                    score_items['利润增长'] = 10
                    reasons.append(f'净利润+{pyoy:.1f}%')
            if ryoy is not None:
                ryoy_pass = ryoy > 0
                level2_checks.append({
                    'name': '营收同比', 'passed': ryoy_pass,
                    'detail': f'{ryoy:+.1f}%' if ryoy_pass else f'{ryoy:+.1f}% (负增长)'
                })
                if ryoy_pass:
                    score += 5
                    score_items['营收增长'] = 5
                    reasons.append(f'营收+{ryoy:.1f}%')

        # === Level 3: 技术指标 ===
        kline = fetcher.get_kline_data(code, days=60)
        if isinstance(kline, dict) and 'error' in kline:
            continue
        if not kline or len(kline) < 20:
            continue

        # MA 金叉
        if l3.get('ma_cross'):
            ma5 = sum(k['close'] for k in kline[-5:]) / 5
            ma20 = sum(k['close'] for k in kline[-20:]) / 20
            ma_pass = ma5 > ma20
            diff_pct = round((ma5 - ma20) / ma20 * 100, 2)
            level3_checks.append({
                'name': 'MA5上穿MA20', 'passed': ma_pass,
                'detail': f'MA5={ma5:.2f} MA20={ma20:.2f} 偏离{diff_pct}%' if ma_pass else f'MA5={ma5:.2f} < MA20={ma20:.2f}'
            })
            if ma_pass:
                score += 20
                score_items['MA金叉'] = 20
                reasons.append('MA5>MA20')
        else:
            level3_checks.append({
                'name': 'MA金叉', 'passed': True, 'detail': '未启用（跳过）'
            })

        # MACD 金叉
        if l3.get('macd_cross'):
            closes = [k['close'] for k in kline]
            ema12 = calc_ema(closes, 12)
            ema26 = calc_ema(closes, 26)
            dif = ema12[-1] - ema26[-1]
            dif_series = [ema12[i] - ema26[i] for i in range(len(ema12))]
            dea = calc_ema(dif_series, 9)[-1]
            macd_pass = dif > dea and dif > 0
            level3_checks.append({
                'name': 'MACD金叉(零轴上)', 'passed': macd_pass,
                'detail': f'DIF={dif:.3f} DEA={dea:.3f}' if macd_pass else f'DIF={dif:.3f} DEA={dea:.3f} 未金叉'
            })
            if macd_pass:
                score += 25
                score_items['MACD金叉'] = 25
                reasons.append('MACD金叉')
        else:
            level3_checks.append({
                'name': 'MACD金叉', 'passed': True, 'detail': '未启用（跳过）'
            })

        # 放量突破
        if l3.get('volume_break'):
            if len(kline) >= 6:
                avg_vol_5 = sum(k['volume'] for k in kline[-6:-1]) / 5
                today_vol = kline[-1]['volume']
                vol_ratio = today_vol / avg_vol_5 if avg_vol_5 > 0 else 0
                vol_pass = vol_ratio > 2
                level3_checks.append({
                    'name': '放量突破(量比>2)', 'passed': vol_pass,
                    'detail': f'今日量/{"%.0f"%(avg_vol_5/10000)}万均量={vol_ratio:.1f}倍' if vol_pass else f'量比={vol_ratio:.1f}倍'
                })
                if vol_pass:
                    score += 25
                    score_items['放量突破'] = 25
                    reasons.append('放量突破')
            else:
                level3_checks.append({
                    'name': '放量突破', 'passed': False, 'detail': '数据不足'
                })
        else:
            level3_checks.append({
                'name': '放量突破', 'passed': True, 'detail': '未启用（跳过）'
            })

        # KDJ 低位
        if l3.get('kdj_cross'):
            high_n = max(k['high'] for k in kline[-9:])
            low_n = min(k['low'] for k in kline[-9:])
            if high_n != low_n:
                rsv = (kline[-1]['close'] - low_n) / (high_n - low_n) * 100
                kdj_pass = rsv < 20
                level3_checks.append({
                    'name': 'KDJ低位(RSV<20)', 'passed': kdj_pass,
                    'detail': f'RSV={rsv:.1f}' if kdj_pass else f'RSV={rsv:.1f} 未到低位'
                })
                if kdj_pass:
                    score += 15
                    score_items['KDJ低位'] = 15
                    reasons.append('KDJ低位')
            else:
                level3_checks.append({
                    'name': 'KDJ低位', 'passed': False, 'detail': '高低价相同'
                })
        else:
            level3_checks.append({
                'name': 'KDJ低位', 'passed': True, 'detail': '未启用（跳过）'
            })

        # RSI 超卖
        if l3.get('rsi_oversold'):
            rsi_val = calc_rsi([k['close'] for k in kline], 14)
            rsi_pass = rsi_val < 30
            level3_checks.append({
                'name': 'RSI超卖(<30)', 'passed': rsi_pass,
                'detail': f'RSI={rsi_val:.1f}' if rsi_pass else f'RSI={rsi_val:.1f}'
            })
            if rsi_pass:
                score += 15
                score_items['RSI超卖'] = 15
                reasons.append('RSI超卖')
        else:
            level3_checks.append({
                'name': 'RSI超卖', 'passed': True, 'detail': '未启用（跳过）'
            })

        # 主力净流入加分（北向偏好代理）
        # skip_northbound: 定时任务用，跳过每只票 10s 的 AKShare 阻塞调用（当前该接口基本返回 None，不影响评分）
        nb = None if conditions.get('skip_northbound') else fetcher.get_northbound_flow(code)
        if nb and nb['bullish']:
            score += 15
            score_items['主力净流入'] = 15
            reasons.append(f'主力净流入{nb["net_5d"]:.0f}万')
            level3_checks.append({
                'name': '主力净流入', 'passed': True,
                'detail': f'5日累计+{nb["net_5d"]:.0f}万'
            })

        if score > 0:
            results.append({
                'stock_code': code,
                'stock_name': name,
                'score': score,
                'price': price,
                'change_pct': change_pct,
                'volume_ratio': volume_ratio,
                'turnover': turnover,
                'reasons': ', '.join(reasons),
                'score_items': score_items,
                'level_details': {
                    'level1': {'name': '基础筛选', 'checks': level1_checks},
                    'level2': {'name': '财务筛选', 'checks': level2_checks},
                    'level3': {'name': '技术指标', 'checks': level3_checks},
                }
            })

    fund_db.close()
    results.sort(key=lambda x: x['score'], reverse=True)

    try:
        today = today_str
        db = get_db()
        try:
            db.execute("DELETE FROM screener_results WHERE date=?", (today,))
            for r in results[:30]:
                db.execute(
                    """INSERT INTO screener_results
                    (date, stock_code, stock_name, score, reasons, price, change_pct, volume_ratio, turnover, passed_level1, passed_level2, passed_level3)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (today, r['stock_code'], r['stock_name'], r['score'], r['reasons'],
                     r.get('price', 0), r.get('change_pct', 0), r.get('volume_ratio', 0), r.get('turnover', 0),
                     1, 1, 1))
            db.commit()
        finally:
            db.close()
    except:
        pass
    return results[:30]


def calc_ema(data, period):
    ema = [data[0]]
    k = 2 / (period + 1)
    for i in range(1, len(data)):
        ema.append(data[i] * k + ema[-1] * (1 - k))
    return ema


def calc_rsi(closes, period):
    if len(closes) < period + 1:
        return 50
    gains = [max(0, closes[i] - closes[i-1]) for i in range(1, len(closes))]
    losses = [abs(min(0, closes[i] - closes[i-1])) for i in range(1, len(closes))]
    avg_gain = sum(gains[-period:]) / period
    avg_loss = sum(losses[-period:]) / period
    if avg_loss == 0:
        return 100
    return 100 - 100 / (1 + avg_gain / avg_loss)
