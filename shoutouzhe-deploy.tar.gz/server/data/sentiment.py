from ..data import fetcher

def get_sentiment():
    stocks = fetcher.get_stock_list()
    if isinstance(stocks, dict) and 'error' in stocks:
        return {'greed_index': 50, 'status': '数据获取失败'}

    up = sum(1 for s in stocks if float(s.get('涨跌幅', 0)) > 0)
    down = sum(1 for s in stocks if float(s.get('涨跌幅', 0)) < 0)
    total = len(stocks)

    up_ratio = up / max(up + down, 1) * 100
    greed = min(100, max(0, round(up_ratio)))

    status = '恐慌' if greed < 30 else ('贪婪' if greed > 70 else '中性')
    return {
        'greed_index': greed,
        'status': status,
        'up_count': up,
        'down_count': down,
        'total_count': total,
        'up_ratio': round(up_ratio, 1)
    }
